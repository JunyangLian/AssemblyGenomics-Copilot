# NSP5 完整配对审核材料

有答案的材料复核；不能作为盲审。两题均需独立读取原文。

# qc_007 逐记录材料复核

私有审核补充；不是盲审、真人专家审核或模型成绩。候选答案未改、未冻结。

## 每条 CDS → FAA 精确连接

| GFF 行 | protein_id | FAA header 行 | 精确连接 |
|---|---|---|---|
| 6 | XP_003381385.1 | 1 | True |
| 7 | XP_003381385.1 | 1 | True |
| 13 | XP_003381386.1 | 5 | True |
| 14 | XP_003381386.1 | 5 | True |
| 15 | XP_003381386.1 | 5 | True |

## 全部直接 Parent 关系

| 子行/类型 | Parent | 父行/类型 | 子区间 | 父区间 | 序列相同 | 链相同 | 合同成立 |
|---|---|---|---|---|---|---|---|
| 3/mRNA | gene-Tsp_07077_1 | []/None | [1631, 2479] | None | False | False | False |
| 4/exon | rna-XM_003381337.1 | [3]/mRNA | [1631, 1931] | [1631, 2479] | True | True | True |
| 5/exon | rna-XM_003381337.1 | [3]/mRNA | [2313, 2479] | [1631, 2479] | True | True | True |
| 6/CDS | rna-XM_003381337.1 | [3]/mRNA | [1631, 1931] | [1631, 2479] | True | True | True |
| 7/CDS | rna-XM_003381337.1 | [3]/mRNA | [2313, 2479] | [1631, 2479] | True | True | True |
| 9/mRNA | gene-Tsp_07078 | [8]/gene | [3838, 5232] | [3838, 5232] | True | True | True |
| 10/exon | rna-XM_003381338.1 | [9]/mRNA | [5092, 5232] | [3838, 5232] | True | True | True |
| 11/exon | rna-XM_003381338.1 | [9]/mRNA | [4129, 5039] | [3838, 5232] | True | True | True |
| 12/exon | rna-XM_003381338.1 | [9]/mRNA | [3838, 4075] | [3838, 5232] | True | True | True |
| 13/CDS | rna-XM_003381338.1 | [9]/mRNA | [5092, 5232] | [3838, 5232] | True | True | True |
| 14/CDS | rna-XM_003381338.1 | [9]/mRNA | [4129, 5039] | [3838, 5232] | True | True | True |
| 15/CDS | rna-XM_003381338.1 | [9]/mRNA | [3838, 4075] | [3838, 5232] | True | True | True |

## 候选引用逐项定位

### E01

mRNA 的 Parent 在完整块中没有对应 gene。

- artifacts/models.gff3:3

```text
NW_003526940.1	RefSeq	mRNA	1631	2479	.	+	.	ID=rna-XM_003381337.1;Parent=gene-Tsp_07077_1;Dbxref=GenBank:XM_003381337.1,GeneID:10903084;Name=XM_003381337.1;gbkey=mRNA;locus_tag=Tsp_07077;product=conserved hypothetical protein;transcript_id=XM_003381337.1
```

- artifacts/models.gff3:2

```text
NW_003526940.1	RefSeq	gene	1631	2479	.	+	.	ID=gene-Tsp_07077;Dbxref=GeneID:10903084;Name=Tsp_07077;gbkey=Gene;gene_biotype=protein_coding;locus_tag=Tsp_07077
```

原候选是代表性定位；完成全记录核对还需要以下行。此处补充材料，不修改 expected.json：

artifacts/models.gff3:8

## 完整公开题目与候选答案

以下逐文件原文供复核。代码框行号与文件自身的行号不同，请以原始附件或上面的 pointer 为准。

### task.md

````text
# 下游输入审核

请审核Trichinella spiralis的一组结构注释记录是否可以交给下游文件连接程序。输出统一规定的JSON。

本题审核输入文件，不是已完成的分析交付；没有提供可回退的旧版本。审核范围仅为给出的两套完整编码gene特征块及对应蛋白，不能外推全基因组注释质量。models.gff3是本次输入，proteins.faa是按ID查找序列的输入；record_counts.json仅列字面计数。

消费者读取GFF的Parent建立gene→mRNA→exon/CDS关系，并按每行CDS的protein_id精确查找FAA header第一个token。每个Parent必须在本题完整记录中存在且类型符合上述层级；子记录必须与父记录同seqid、同链，闭区间完全位于父记录内。FAA记录与不同protein_id对应的一组CDS一一相接。没有声明去版本号、改大小写、以Name或CDS ID代替protein_id等映射。

同一CDS的多片段可以重复ID，不能把CDS行数当蛋白条数。允许异构体和partial=true，不检查模型全长、翻译正确性或生物学功能；这些属性不豁免上述文件连接要求。除必要输入合同外，本题没有其它继续条件，也没有提供运行日志来解释上游过程。

请根据公开记录检查必要合同，并建议最小修复或补证。满足所有必要输入要求时可继续；必要连接或层级要求不能满足时，应先停止下游启动并修复。不要仅凭字面计数接近就认为可以继续。
````

### artifacts/models.gff3

````text
##gff-version 3
NW_003526940.1	RefSeq	gene	1631	2479	.	+	.	ID=gene-Tsp_07077;Dbxref=GeneID:10903084;Name=Tsp_07077;gbkey=Gene;gene_biotype=protein_coding;locus_tag=Tsp_07077
NW_003526940.1	RefSeq	mRNA	1631	2479	.	+	.	ID=rna-XM_003381337.1;Parent=gene-Tsp_07077_1;Dbxref=GenBank:XM_003381337.1,GeneID:10903084;Name=XM_003381337.1;gbkey=mRNA;locus_tag=Tsp_07077;product=conserved hypothetical protein;transcript_id=XM_003381337.1
NW_003526940.1	RefSeq	exon	1631	1931	.	+	.	ID=exon-XM_003381337.1-1;Parent=rna-XM_003381337.1;Dbxref=GenBank:XM_003381337.1,GeneID:10903084;gbkey=mRNA;locus_tag=Tsp_07077;product=conserved hypothetical protein;transcript_id=XM_003381337.1
NW_003526940.1	RefSeq	exon	2313	2479	.	+	.	ID=exon-XM_003381337.1-2;Parent=rna-XM_003381337.1;Dbxref=GenBank:XM_003381337.1,GeneID:10903084;gbkey=mRNA;locus_tag=Tsp_07077;product=conserved hypothetical protein;transcript_id=XM_003381337.1
NW_003526940.1	RefSeq	CDS	1631	1931	.	+	0	ID=cds-XP_003381385.1;Parent=rna-XM_003381337.1;Dbxref=GenBank:XP_003381385.1,GeneID:10903084;Name=XP_003381385.1;gbkey=CDS;locus_tag=Tsp_07077;product=hypothetical protein;protein_id=XP_003381385.1
NW_003526940.1	RefSeq	CDS	2313	2479	.	+	2	ID=cds-XP_003381385.1;Parent=rna-XM_003381337.1;Dbxref=GenBank:XP_003381385.1,GeneID:10903084;Name=XP_003381385.1;gbkey=CDS;locus_tag=Tsp_07077;product=hypothetical protein;protein_id=XP_003381385.1
NW_003526940.1	RefSeq	gene	3838	5232	.	-	.	ID=gene-Tsp_07078;Dbxref=GeneID:10897948;Name=Tsp_07078;gbkey=Gene;gene_biotype=protein_coding;locus_tag=Tsp_07078
NW_003526940.1	RefSeq	mRNA	3838	5232	.	-	.	ID=rna-XM_003381338.1;Parent=gene-Tsp_07078;Dbxref=GenBank:XM_003381338.1,GeneID:10897948;Name=XM_003381338.1;gbkey=mRNA;locus_tag=Tsp_07078;product=hypothetical protein;transcript_id=XM_003381338.1
NW_003526940.1	RefSeq	exon	5092	5232	.	-	.	ID=exon-XM_003381338.1-1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XM_003381338.1,GeneID:10897948;gbkey=mRNA;locus_tag=Tsp_07078;product=hypothetical protein;transcript_id=XM_003381338.1
NW_003526940.1	RefSeq	exon	4129	5039	.	-	.	ID=exon-XM_003381338.1-2;Parent=rna-XM_003381338.1;Dbxref=GenBank:XM_003381338.1,GeneID:10897948;gbkey=mRNA;locus_tag=Tsp_07078;product=hypothetical protein;transcript_id=XM_003381338.1
NW_003526940.1	RefSeq	exon	3838	4075	.	-	.	ID=exon-XM_003381338.1-3;Parent=rna-XM_003381338.1;Dbxref=GenBank:XM_003381338.1,GeneID:10897948;gbkey=mRNA;locus_tag=Tsp_07078;product=hypothetical protein;transcript_id=XM_003381338.1
NW_003526940.1	RefSeq	CDS	5092	5232	.	-	0	ID=cds-XP_003381386.1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XP_003381386.1,GeneID:10897948;Name=XP_003381386.1;gbkey=CDS;locus_tag=Tsp_07078;product=hypothetical protein;protein_id=XP_003381386.1
NW_003526940.1	RefSeq	CDS	4129	5039	.	-	0	ID=cds-XP_003381386.1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XP_003381386.1,GeneID:10897948;Name=XP_003381386.1;gbkey=CDS;locus_tag=Tsp_07078;product=hypothetical protein;protein_id=XP_003381386.1
NW_003526940.1	RefSeq	CDS	3838	4075	.	-	1	ID=cds-XP_003381386.1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XP_003381386.1,GeneID:10897948;Name=XP_003381386.1;gbkey=CDS;locus_tag=Tsp_07078;product=hypothetical protein;protein_id=XP_003381386.1
````

### artifacts/proteins.faa

````text
>XP_003381385.1 conserved hypothetical protein [Trichinella spiralis]
MASRFLTLENAIDYLETLPPEDQINAEVCQLPPCEDGNLTDEEHIEEDDLDEVMPLDVCG
EVDVTVDSDRIVNEDDVTTNKGYGYNSKCQNTQLPPYEAGIPKGNHHPFIAREAIRNKPP
RATVTLTNKTPDFVRALPPIMCPWTMCSLPKKLQK
>XP_003381386.1 hypothetical protein Tsp_07078 [Trichinella spiralis]
MANVPEWHLVQNRCGGTSLFHEGRAYRLKRAGRQKYWRCSQVCAKCTGCGGAVWTNLDVT
TVIKRNDYIESCPVDEHLAYKMEKRAALTKRSAEETKPIPAIYDEEASAASAEPSISGHF
PLFRRLRAAMYGHRAKRFPRLPEHRHDLVIPDQFKTTKSGEDFLLCQSNCRHILVFATGT
NIRLLAACRTWGMDGTFKIIPQWYQQLFTIHVFVAGKLVPAVYCLCTGKDIGTCGYIFQA
LIDKAAVLEVDLNPDTIICDFETALIPAIRGYFPNTRVQGCYFYFCQAVHRKVDELGLKT
RYRTEEGTRRKIRMLLATAFLPVAEIDTSVRLLETGTTGTLAALFQYFRQETNNHNRLNR
KAAKSHNGLYELLQLLIAEQGVMDTLIHQVLSGNATVGDLRWVNKVYAQKQRQFARYTGE
YTNGRRTLE
````

### artifacts/record_counts.json

````text
{"cds_rows":5,"exon_rows":5,"gene_rows":2,"mrna_rows":2,"protein_records":2,"protein_residues":584,"unique_cds_ids":2}
````

### expected.json

````text
{"acceptable_decisions":[{"observed_defect":"gff_reference_unresolved","root_cause":"gff_hierarchy_error","verdict":"block"}],"case_id":"qc_007","independent_review_status":"pending","key_evidence":[{"acceptable_pointers":["artifacts/models.gff3:3","artifacts/models.gff3:2"],"claim_id":"E01","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"mRNA 的 Parent 在完整块中没有对应 gene。","verification_method":"record_connection"}],"pair_id":"NSP5","rationale":"仅审核本题声明的文件连接与层级；不推断上游运行原因或生物学质量。","root_identifiability":"confirmed","schema_version":"newsource-case-1","user_approved":false}
````

### meta.json

````text
{"case_id":"qc_007","excerpt_policy":"固定规则选两个原始完整编码gene块和所有关联完整蛋白；仅格式重排LF/FAA60列，不代表完整基因组；确定性变体逐字段记录。","historical_rule_report_seen":true,"injection_script":"bench/newsource_validation/cases.py","mechanism_exposure":"seen_in_project_development","mechanism_family":"parent_reference_closure","pair_id":"NSP5","pressure_parent":null,"review_status":"draft","schema_version":"newsource-case-1","seed":20261011,"source_exposure":"new_to_model_prompt_tool_development","source_files":[{"path":"sources/GCF_000181795.1_Trichinella_spiralis-3.7.1_genomic.gff.gz","selection":"{\"gene_ids\": [\"gene-Tsp_07077\", \"gene-Tsp_07078\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": {\"after\": \"gene-Tsp_07077_1\", \"attribute\": \"Parent\", \"before\": \"gene-Tsp_07077\", \"policy\": \"one mRNA edge; other rows unchanged\"}}","sha256":"da0f3bf2e8f17bf495e832c92a9654b99bba043a2c589beadf2597ce7d5e106f","source_group":"GCF_000181795.1","source_origin":"/home/Lianjunyang/临时/GCF_000181795.1_Trichinella_spiralis-3.7.1_genomic.gff.gz"},{"path":"sources/GCF_000181795.1_Trichinella_spiralis-3.7.1_protein.faa.gz","selection":"{\"gene_ids\": [\"gene-Tsp_07077\", \"gene-Tsp_07078\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": {\"after\": \"gene-Tsp_07077_1\", \"attribute\": \"Parent\", \"before\": \"gene-Tsp_07077\", \"policy\": \"one mRNA edge; other rows unchanged\"}}","sha256":"b062ba2498f4d07dfe0e17a4b55aeaf45b2ec7fd6c829dcdbb7f39189d967681","source_group":"GCF_000181795.1","source_origin":"/home/Lianjunyang/临时/GCF_000181795.1_Trichinella_spiralis-3.7.1_protein.faa.gz"}],"source_group":"GCF_000181795.1","split":"sealed_test","stage":"structural_annotation","synthetic":true,"type":"fault","verbatim_tool_exceptions":[],"visible_contract":{"allowed_id_mapping":"exact only","artifact_roles":{"delivery":["artifacts/models.gff3","artifacts/proteins.faa","artifacts/record_counts.json"],"reference":[]},"consumer_contract":"完整Parent层级、同序列/链、闭区间包含、protein_id精确连接FAA首token","review_target":"input","scope":"declared_subset","usable_previous_result":false}}
````


# qc_010 逐记录材料复核

私有审核补充；不是盲审、真人专家审核或模型成绩。候选答案未改、未冻结。

## 每条 CDS → FAA 精确连接

| GFF 行 | protein_id | FAA header 行 | 精确连接 |
|---|---|---|---|
| 6 | XP_003381385.1 | 1 | True |
| 7 | XP_003381385.1 | 1 | True |
| 13 | XP_003381386.1 | 5 | True |
| 14 | XP_003381386.1 | 5 | True |
| 15 | XP_003381386.1 | 5 | True |

## 全部直接 Parent 关系

| 子行/类型 | Parent | 父行/类型 | 子区间 | 父区间 | 序列相同 | 链相同 | 合同成立 |
|---|---|---|---|---|---|---|---|
| 3/mRNA | gene-Tsp_07077 | [2]/gene | [1631, 2479] | [1631, 2479] | True | True | True |
| 4/exon | rna-XM_003381337.1 | [3]/mRNA | [1631, 1931] | [1631, 2479] | True | True | True |
| 5/exon | rna-XM_003381337.1 | [3]/mRNA | [2313, 2479] | [1631, 2479] | True | True | True |
| 6/CDS | rna-XM_003381337.1 | [3]/mRNA | [1631, 1931] | [1631, 2479] | True | True | True |
| 7/CDS | rna-XM_003381337.1 | [3]/mRNA | [2313, 2479] | [1631, 2479] | True | True | True |
| 9/mRNA | gene-Tsp_07078 | [8]/gene | [3838, 5232] | [3838, 5232] | True | True | True |
| 10/exon | rna-XM_003381338.1 | [9]/mRNA | [5092, 5232] | [3838, 5232] | True | True | True |
| 11/exon | rna-XM_003381338.1 | [9]/mRNA | [4129, 5039] | [3838, 5232] | True | True | True |
| 12/exon | rna-XM_003381338.1 | [9]/mRNA | [3838, 4075] | [3838, 5232] | True | True | True |
| 13/CDS | rna-XM_003381338.1 | [9]/mRNA | [5092, 5232] | [3838, 5232] | True | True | True |
| 14/CDS | rna-XM_003381338.1 | [9]/mRNA | [4129, 5039] | [3838, 5232] | True | True | True |
| 15/CDS | rna-XM_003381338.1 | [9]/mRNA | [3838, 4075] | [3838, 5232] | True | True | True |

## 候选引用逐项定位

### E01

每个不同 CDS protein_id 与完整 FAA 的首 token 精确接续；逐个 ID 验证，不以行数代替。

- artifacts/models.gff3:6

```text
NW_003526940.1	RefSeq	CDS	1631	1931	.	+	0	ID=cds-XP_003381385.1;Parent=rna-XM_003381337.1;Dbxref=GenBank:XP_003381385.1,GeneID:10903084;Name=XP_003381385.1;gbkey=CDS;locus_tag=Tsp_07077;product=hypothetical protein;protein_id=XP_003381385.1
```

- artifacts/models.gff3:7

```text
NW_003526940.1	RefSeq	CDS	2313	2479	.	+	2	ID=cds-XP_003381385.1;Parent=rna-XM_003381337.1;Dbxref=GenBank:XP_003381385.1,GeneID:10903084;Name=XP_003381385.1;gbkey=CDS;locus_tag=Tsp_07077;product=hypothetical protein;protein_id=XP_003381385.1
```

- artifacts/models.gff3:13

```text
NW_003526940.1	RefSeq	CDS	5092	5232	.	-	0	ID=cds-XP_003381386.1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XP_003381386.1,GeneID:10897948;Name=XP_003381386.1;gbkey=CDS;locus_tag=Tsp_07078;product=hypothetical protein;protein_id=XP_003381386.1
```

- artifacts/models.gff3:14

```text
NW_003526940.1	RefSeq	CDS	4129	5039	.	-	0	ID=cds-XP_003381386.1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XP_003381386.1,GeneID:10897948;Name=XP_003381386.1;gbkey=CDS;locus_tag=Tsp_07078;product=hypothetical protein;protein_id=XP_003381386.1
```

- artifacts/models.gff3:15

```text
NW_003526940.1	RefSeq	CDS	3838	4075	.	-	1	ID=cds-XP_003381386.1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XP_003381386.1,GeneID:10897948;Name=XP_003381386.1;gbkey=CDS;locus_tag=Tsp_07078;product=hypothetical protein;protein_id=XP_003381386.1
```

- artifacts/proteins.faa:1

```text
>XP_003381385.1 conserved hypothetical protein [Trichinella spiralis]
```

- artifacts/proteins.faa:5

```text
>XP_003381386.1 hypothetical protein Tsp_07078 [Trichinella spiralis]
```

### E02

所有 Parent 接续且类型、序列/链与父子闭区间符合题面必要合同。

- artifacts/models.gff3:2

```text
NW_003526940.1	RefSeq	gene	1631	2479	.	+	.	ID=gene-Tsp_07077;Dbxref=GeneID:10903084;Name=Tsp_07077;gbkey=Gene;gene_biotype=protein_coding;locus_tag=Tsp_07077
```

- artifacts/models.gff3:3

```text
NW_003526940.1	RefSeq	mRNA	1631	2479	.	+	.	ID=rna-XM_003381337.1;Parent=gene-Tsp_07077;Dbxref=GenBank:XM_003381337.1,GeneID:10903084;Name=XM_003381337.1;gbkey=mRNA;locus_tag=Tsp_07077;product=conserved hypothetical protein;transcript_id=XM_003381337.1
```

- artifacts/models.gff3:8

```text
NW_003526940.1	RefSeq	gene	3838	5232	.	-	.	ID=gene-Tsp_07078;Dbxref=GeneID:10897948;Name=Tsp_07078;gbkey=Gene;gene_biotype=protein_coding;locus_tag=Tsp_07078
```

- artifacts/models.gff3:9

```text
NW_003526940.1	RefSeq	mRNA	3838	5232	.	-	.	ID=rna-XM_003381338.1;Parent=gene-Tsp_07078;Dbxref=GenBank:XM_003381338.1,GeneID:10897948;Name=XM_003381338.1;gbkey=mRNA;locus_tag=Tsp_07078;product=hypothetical protein;transcript_id=XM_003381338.1
```

原候选是代表性定位；完成全记录核对还需要以下行。此处补充材料，不修改 expected.json：

artifacts/models.gff3:4, artifacts/models.gff3:5, artifacts/models.gff3:6, artifacts/models.gff3:7, artifacts/models.gff3:10, artifacts/models.gff3:11, artifacts/models.gff3:12, artifacts/models.gff3:13, artifacts/models.gff3:14, artifacts/models.gff3:15

## 完整公开题目与候选答案

以下逐文件原文供复核。代码框行号与文件自身的行号不同，请以原始附件或上面的 pointer 为准。

### task.md

````text
# 下游输入审核

请审核Trichinella spiralis的一组结构注释记录是否可以交给下游文件连接程序。输出统一规定的JSON。

本题审核输入文件，不是已完成的分析交付；没有提供可回退的旧版本。审核范围仅为给出的两套完整编码gene特征块及对应蛋白，不能外推全基因组注释质量。models.gff3是本次输入，proteins.faa是按ID查找序列的输入；record_counts.json仅列字面计数。

消费者读取GFF的Parent建立gene→mRNA→exon/CDS关系，并按每行CDS的protein_id精确查找FAA header第一个token。每个Parent必须在本题完整记录中存在且类型符合上述层级；子记录必须与父记录同seqid、同链，闭区间完全位于父记录内。FAA记录与不同protein_id对应的一组CDS一一相接。没有声明去版本号、改大小写、以Name或CDS ID代替protein_id等映射。

同一CDS的多片段可以重复ID，不能把CDS行数当蛋白条数。允许异构体和partial=true，不检查模型全长、翻译正确性或生物学功能；这些属性不豁免上述文件连接要求。除必要输入合同外，本题没有其它继续条件，也没有提供运行日志来解释上游过程。

请根据公开记录检查必要合同，并建议最小修复或补证。满足所有必要输入要求时可继续；必要连接或层级要求不能满足时，应先停止下游启动并修复。不要仅凭字面计数接近就认为可以继续。
````

### artifacts/models.gff3

````text
##gff-version 3
NW_003526940.1	RefSeq	gene	1631	2479	.	+	.	ID=gene-Tsp_07077;Dbxref=GeneID:10903084;Name=Tsp_07077;gbkey=Gene;gene_biotype=protein_coding;locus_tag=Tsp_07077
NW_003526940.1	RefSeq	mRNA	1631	2479	.	+	.	ID=rna-XM_003381337.1;Parent=gene-Tsp_07077;Dbxref=GenBank:XM_003381337.1,GeneID:10903084;Name=XM_003381337.1;gbkey=mRNA;locus_tag=Tsp_07077;product=conserved hypothetical protein;transcript_id=XM_003381337.1
NW_003526940.1	RefSeq	exon	1631	1931	.	+	.	ID=exon-XM_003381337.1-1;Parent=rna-XM_003381337.1;Dbxref=GenBank:XM_003381337.1,GeneID:10903084;gbkey=mRNA;locus_tag=Tsp_07077;product=conserved hypothetical protein;transcript_id=XM_003381337.1
NW_003526940.1	RefSeq	exon	2313	2479	.	+	.	ID=exon-XM_003381337.1-2;Parent=rna-XM_003381337.1;Dbxref=GenBank:XM_003381337.1,GeneID:10903084;gbkey=mRNA;locus_tag=Tsp_07077;product=conserved hypothetical protein;transcript_id=XM_003381337.1
NW_003526940.1	RefSeq	CDS	1631	1931	.	+	0	ID=cds-XP_003381385.1;Parent=rna-XM_003381337.1;Dbxref=GenBank:XP_003381385.1,GeneID:10903084;Name=XP_003381385.1;gbkey=CDS;locus_tag=Tsp_07077;product=hypothetical protein;protein_id=XP_003381385.1
NW_003526940.1	RefSeq	CDS	2313	2479	.	+	2	ID=cds-XP_003381385.1;Parent=rna-XM_003381337.1;Dbxref=GenBank:XP_003381385.1,GeneID:10903084;Name=XP_003381385.1;gbkey=CDS;locus_tag=Tsp_07077;product=hypothetical protein;protein_id=XP_003381385.1
NW_003526940.1	RefSeq	gene	3838	5232	.	-	.	ID=gene-Tsp_07078;Dbxref=GeneID:10897948;Name=Tsp_07078;gbkey=Gene;gene_biotype=protein_coding;locus_tag=Tsp_07078
NW_003526940.1	RefSeq	mRNA	3838	5232	.	-	.	ID=rna-XM_003381338.1;Parent=gene-Tsp_07078;Dbxref=GenBank:XM_003381338.1,GeneID:10897948;Name=XM_003381338.1;gbkey=mRNA;locus_tag=Tsp_07078;product=hypothetical protein;transcript_id=XM_003381338.1
NW_003526940.1	RefSeq	exon	5092	5232	.	-	.	ID=exon-XM_003381338.1-1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XM_003381338.1,GeneID:10897948;gbkey=mRNA;locus_tag=Tsp_07078;product=hypothetical protein;transcript_id=XM_003381338.1
NW_003526940.1	RefSeq	exon	4129	5039	.	-	.	ID=exon-XM_003381338.1-2;Parent=rna-XM_003381338.1;Dbxref=GenBank:XM_003381338.1,GeneID:10897948;gbkey=mRNA;locus_tag=Tsp_07078;product=hypothetical protein;transcript_id=XM_003381338.1
NW_003526940.1	RefSeq	exon	3838	4075	.	-	.	ID=exon-XM_003381338.1-3;Parent=rna-XM_003381338.1;Dbxref=GenBank:XM_003381338.1,GeneID:10897948;gbkey=mRNA;locus_tag=Tsp_07078;product=hypothetical protein;transcript_id=XM_003381338.1
NW_003526940.1	RefSeq	CDS	5092	5232	.	-	0	ID=cds-XP_003381386.1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XP_003381386.1,GeneID:10897948;Name=XP_003381386.1;gbkey=CDS;locus_tag=Tsp_07078;product=hypothetical protein;protein_id=XP_003381386.1
NW_003526940.1	RefSeq	CDS	4129	5039	.	-	0	ID=cds-XP_003381386.1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XP_003381386.1,GeneID:10897948;Name=XP_003381386.1;gbkey=CDS;locus_tag=Tsp_07078;product=hypothetical protein;protein_id=XP_003381386.1
NW_003526940.1	RefSeq	CDS	3838	4075	.	-	1	ID=cds-XP_003381386.1;Parent=rna-XM_003381338.1;Dbxref=GenBank:XP_003381386.1,GeneID:10897948;Name=XP_003381386.1;gbkey=CDS;locus_tag=Tsp_07078;product=hypothetical protein;protein_id=XP_003381386.1
````

### artifacts/proteins.faa

````text
>XP_003381385.1 conserved hypothetical protein [Trichinella spiralis]
MASRFLTLENAIDYLETLPPEDQINAEVCQLPPCEDGNLTDEEHIEEDDLDEVMPLDVCG
EVDVTVDSDRIVNEDDVTTNKGYGYNSKCQNTQLPPYEAGIPKGNHHPFIAREAIRNKPP
RATVTLTNKTPDFVRALPPIMCPWTMCSLPKKLQK
>XP_003381386.1 hypothetical protein Tsp_07078 [Trichinella spiralis]
MANVPEWHLVQNRCGGTSLFHEGRAYRLKRAGRQKYWRCSQVCAKCTGCGGAVWTNLDVT
TVIKRNDYIESCPVDEHLAYKMEKRAALTKRSAEETKPIPAIYDEEASAASAEPSISGHF
PLFRRLRAAMYGHRAKRFPRLPEHRHDLVIPDQFKTTKSGEDFLLCQSNCRHILVFATGT
NIRLLAACRTWGMDGTFKIIPQWYQQLFTIHVFVAGKLVPAVYCLCTGKDIGTCGYIFQA
LIDKAAVLEVDLNPDTIICDFETALIPAIRGYFPNTRVQGCYFYFCQAVHRKVDELGLKT
RYRTEEGTRRKIRMLLATAFLPVAEIDTSVRLLETGTTGTLAALFQYFRQETNNHNRLNR
KAAKSHNGLYELLQLLIAEQGVMDTLIHQVLSGNATVGDLRWVNKVYAQKQRQFARYTGE
YTNGRRTLE
````

### artifacts/record_counts.json

````text
{"cds_rows":5,"exon_rows":5,"gene_rows":2,"mrna_rows":2,"protein_records":2,"protein_residues":584,"unique_cds_ids":2}
````

### expected.json

````text
{"acceptable_decisions":[{"observed_defect":"none","root_cause":"none","verdict":"pass"}],"case_id":"qc_010","independent_review_status":"pending","key_evidence":[{"acceptable_pointers":["artifacts/models.gff3:6","artifacts/models.gff3:7","artifacts/models.gff3:13","artifacts/models.gff3:14","artifacts/models.gff3:15","artifacts/proteins.faa:1","artifacts/proteins.faa:5"],"claim_id":"E01","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"每个不同 CDS protein_id 与完整 FAA 的首 token 精确接续；逐个 ID 验证，不以行数代替。","verification_method":"record_connection"},{"acceptable_pointers":["artifacts/models.gff3:2","artifacts/models.gff3:3","artifacts/models.gff3:8","artifacts/models.gff3:9"],"claim_id":"E02","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"所有 Parent 接续且类型、序列/链与父子闭区间符合题面必要合同。","verification_method":"record_connection"}],"pair_id":"NSP5","rationale":"仅审核本题声明的文件连接与层级；不推断上游运行原因或生物学质量。","root_identifiability":"no_defect","schema_version":"newsource-case-1","user_approved":false}
````

### meta.json

````text
{"case_id":"qc_010","excerpt_policy":"固定规则选两个原始完整编码gene块和所有关联完整蛋白；仅格式重排LF/FAA60列，不代表完整基因组；确定性变体逐字段记录。","historical_rule_report_seen":true,"injection_script":"bench/newsource_validation/cases.py","mechanism_exposure":"seen_in_project_development","mechanism_family":"parent_reference_closure","pair_id":"NSP5","pressure_parent":null,"review_status":"draft","schema_version":"newsource-case-1","seed":20261011,"source_exposure":"new_to_model_prompt_tool_development","source_files":[{"path":"sources/GCF_000181795.1_Trichinella_spiralis-3.7.1_genomic.gff.gz","selection":"{\"gene_ids\": [\"gene-Tsp_07077\", \"gene-Tsp_07078\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": \"unmodified source subset\"}","sha256":"da0f3bf2e8f17bf495e832c92a9654b99bba043a2c589beadf2597ce7d5e106f","source_group":"GCF_000181795.1","source_origin":"/home/Lianjunyang/临时/GCF_000181795.1_Trichinella_spiralis-3.7.1_genomic.gff.gz"},{"path":"sources/GCF_000181795.1_Trichinella_spiralis-3.7.1_protein.faa.gz","selection":"{\"gene_ids\": [\"gene-Tsp_07077\", \"gene-Tsp_07078\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": \"unmodified source subset\"}","sha256":"b062ba2498f4d07dfe0e17a4b55aeaf45b2ec7fd6c829dcdbb7f39189d967681","source_group":"GCF_000181795.1","source_origin":"/home/Lianjunyang/临时/GCF_000181795.1_Trichinella_spiralis-3.7.1_protein.faa.gz"}],"source_group":"GCF_000181795.1","split":"sealed_test","stage":"structural_annotation","synthetic":true,"type":"normal","verbatim_tool_exceptions":[],"visible_contract":{"allowed_id_mapping":"exact only","artifact_roles":{"delivery":["artifacts/models.gff3","artifacts/proteins.faa","artifacts/record_counts.json"],"reference":[]},"consumer_contract":"完整Parent层级、同序列/链、闭区间包含、protein_id精确连接FAA首token","review_target":"input","scope":"declared_subset","usable_previous_result":false}}
````
