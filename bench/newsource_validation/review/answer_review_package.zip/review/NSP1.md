# NSP1 完整配对审核材料

有答案的材料复核；不能作为盲审。两题均需独立读取原文。

# qc_006 逐记录材料复核

私有审核补充；不是盲审、真人专家审核或模型成绩。候选答案未改、未冻结。

## 每条 CDS → FAA 精确连接

| GFF 行 | protein_id | FAA header 行 | 精确连接 |
|---|---|---|---|
| 9 | XP_088235420.101 | None | False |
| 10 | XP_088235420.101 | None | False |
| 11 | XP_088235420.101 | None | False |
| 12 | XP_088235420.101 | None | False |
| 13 | XP_088235420.101 | None | False |
| 31 | XP_088235409.1 | 1 | True |
| 32 | XP_088235409.1 | 1 | True |
| 33 | XP_088235409.1 | 1 | True |
| 34 | XP_088235409.1 | 1 | True |
| 35 | XP_088235409.1 | 1 | True |
| 36 | XP_088235409.1 | 1 | True |
| 37 | XP_088235409.1 | 1 | True |
| 38 | XP_088235409.1 | 1 | True |
| 39 | XP_088235409.1 | 1 | True |
| 40 | XP_088235409.1 | 1 | True |
| 41 | XP_088235409.1 | 1 | True |
| 42 | XP_088235409.1 | 1 | True |
| 43 | XP_088235409.1 | 1 | True |
| 44 | XP_088235409.1 | 1 | True |
| 45 | XP_088235409.1 | 1 | True |

## 全部直接 Parent 关系

| 子行/类型 | Parent | 父行/类型 | 子区间 | 父区间 | 序列相同 | 链相同 | 合同成立 |
|---|---|---|---|---|---|---|---|
| 3/mRNA | gene-syt4 | [2]/gene | [16146, 21098] | [16146, 21098] | True | True | True |
| 4/exon | rna-XM_088379294.1 | [3]/mRNA | [20519, 21098] | [16146, 21098] | True | True | True |
| 5/exon | rna-XM_088379294.1 | [3]/mRNA | [18421, 18977] | [16146, 21098] | True | True | True |
| 6/exon | rna-XM_088379294.1 | [3]/mRNA | [17523, 17846] | [16146, 21098] | True | True | True |
| 7/exon | rna-XM_088379294.1 | [3]/mRNA | [17334, 17454] | [16146, 21098] | True | True | True |
| 8/exon | rna-XM_088379294.1 | [3]/mRNA | [16146, 17251] | [16146, 21098] | True | True | True |
| 9/CDS | rna-XM_088379294.1 | [3]/mRNA | [20519, 20555] | [16146, 21098] | True | True | True |
| 10/CDS | rna-XM_088379294.1 | [3]/mRNA | [18421, 18977] | [16146, 21098] | True | True | True |
| 11/CDS | rna-XM_088379294.1 | [3]/mRNA | [17523, 17846] | [16146, 21098] | True | True | True |
| 12/CDS | rna-XM_088379294.1 | [3]/mRNA | [17334, 17454] | [16146, 21098] | True | True | True |
| 13/CDS | rna-XM_088379294.1 | [3]/mRNA | [16932, 17251] | [16146, 21098] | True | True | True |
| 15/mRNA | gene-sema4f | [14]/gene | [21247, 31380] | [21247, 31380] | True | True | True |
| 16/exon | rna-XM_088379283.1 | [15]/mRNA | [30790, 31380] | [21247, 31380] | True | True | True |
| 17/exon | rna-XM_088379283.1 | [15]/mRNA | [26714, 26859] | [21247, 31380] | True | True | True |
| 18/exon | rna-XM_088379283.1 | [15]/mRNA | [26587, 26646] | [21247, 31380] | True | True | True |
| 19/exon | rna-XM_088379283.1 | [15]/mRNA | [26061, 26162] | [21247, 31380] | True | True | True |
| 20/exon | rna-XM_088379283.1 | [15]/mRNA | [25864, 25975] | [21247, 31380] | True | True | True |
| 21/exon | rna-XM_088379283.1 | [15]/mRNA | [25677, 25796] | [21247, 31380] | True | True | True |
| 22/exon | rna-XM_088379283.1 | [15]/mRNA | [25437, 25591] | [21247, 31380] | True | True | True |
| 23/exon | rna-XM_088379283.1 | [15]/mRNA | [25125, 25306] | [21247, 31380] | True | True | True |
| 24/exon | rna-XM_088379283.1 | [15]/mRNA | [24901, 25030] | [21247, 31380] | True | True | True |
| 25/exon | rna-XM_088379283.1 | [15]/mRNA | [24019, 24235] | [21247, 31380] | True | True | True |
| 26/exon | rna-XM_088379283.1 | [15]/mRNA | [23844, 23953] | [21247, 31380] | True | True | True |
| 27/exon | rna-XM_088379283.1 | [15]/mRNA | [23618, 23769] | [21247, 31380] | True | True | True |
| 28/exon | rna-XM_088379283.1 | [15]/mRNA | [23393, 23448] | [21247, 31380] | True | True | True |
| 29/exon | rna-XM_088379283.1 | [15]/mRNA | [22838, 23031] | [21247, 31380] | True | True | True |
| 30/exon | rna-XM_088379283.1 | [15]/mRNA | [21247, 22402] | [21247, 31380] | True | True | True |
| 31/CDS | rna-XM_088379283.1 | [15]/mRNA | [30790, 30880] | [21247, 31380] | True | True | True |
| 32/CDS | rna-XM_088379283.1 | [15]/mRNA | [26714, 26859] | [21247, 31380] | True | True | True |
| 33/CDS | rna-XM_088379283.1 | [15]/mRNA | [26587, 26646] | [21247, 31380] | True | True | True |
| 34/CDS | rna-XM_088379283.1 | [15]/mRNA | [26061, 26162] | [21247, 31380] | True | True | True |
| 35/CDS | rna-XM_088379283.1 | [15]/mRNA | [25864, 25975] | [21247, 31380] | True | True | True |
| 36/CDS | rna-XM_088379283.1 | [15]/mRNA | [25677, 25796] | [21247, 31380] | True | True | True |
| 37/CDS | rna-XM_088379283.1 | [15]/mRNA | [25437, 25591] | [21247, 31380] | True | True | True |
| 38/CDS | rna-XM_088379283.1 | [15]/mRNA | [25125, 25306] | [21247, 31380] | True | True | True |
| 39/CDS | rna-XM_088379283.1 | [15]/mRNA | [24901, 25030] | [21247, 31380] | True | True | True |
| 40/CDS | rna-XM_088379283.1 | [15]/mRNA | [24019, 24235] | [21247, 31380] | True | True | True |
| 41/CDS | rna-XM_088379283.1 | [15]/mRNA | [23844, 23953] | [21247, 31380] | True | True | True |
| 42/CDS | rna-XM_088379283.1 | [15]/mRNA | [23618, 23769] | [21247, 31380] | True | True | True |
| 43/CDS | rna-XM_088379283.1 | [15]/mRNA | [23393, 23448] | [21247, 31380] | True | True | True |
| 44/CDS | rna-XM_088379283.1 | [15]/mRNA | [22838, 23031] | [21247, 31380] | True | True | True |
| 45/CDS | rna-XM_088379283.1 | [15]/mRNA | [21932, 22402] | [21247, 31380] | True | True | True |

## 候选引用逐项定位

### E01

CDS protein_id 在本题全部 FAA 首 token 中无精确匹配；不允许改用其它标识。

- artifacts/models.gff3:9

```text
NC_142413.1	Gnomon	CDS	20519	20555	.	-	0	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.101
```

- artifacts/proteins.faa:1

```text
>XP_088235409.1 semaphorin-4F [Syngnathus floridae]
```

- artifacts/proteins.faa:15

```text
>XP_088235420.1 synaptotagmin-4 [Syngnathus floridae]
```

原候选是代表性定位；完成全记录核对还需要以下行。此处补充材料，不修改 expected.json：

artifacts/models.gff3:10, artifacts/models.gff3:11, artifacts/models.gff3:12, artifacts/models.gff3:13

## 完整公开题目与候选答案

以下逐文件原文供复核。代码框行号与文件自身的行号不同，请以原始附件或上面的 pointer 为准。

### task.md

````text
# 下游输入审核

请审核Syngnathus floridae的一组结构注释记录是否可以交给下游文件连接程序。输出统一规定的JSON。

本题审核输入文件，不是已完成的分析交付；没有提供可回退的旧版本。审核范围仅为给出的两套完整编码gene特征块及对应蛋白，不能外推全基因组注释质量。models.gff3是本次输入，proteins.faa是按ID查找序列的输入；record_counts.json仅列字面计数。

消费者读取GFF的Parent建立gene→mRNA→exon/CDS关系，并按每行CDS的protein_id精确查找FAA header第一个token。每个Parent必须在本题完整记录中存在且类型符合上述层级；子记录必须与父记录同seqid、同链，闭区间完全位于父记录内。FAA记录与不同protein_id对应的一组CDS一一相接。没有声明去版本号、改大小写、以Name或CDS ID代替protein_id等映射。

同一CDS的多片段可以重复ID，不能把CDS行数当蛋白条数。允许异构体和partial=true，不检查模型全长、翻译正确性或生物学功能；这些属性不豁免上述文件连接要求。除必要输入合同外，本题没有其它继续条件，也没有提供运行日志来解释上游过程。

请根据公开记录检查必要合同，并建议最小修复或补证。满足所有必要输入要求时可继续；必要连接或层级要求不能满足时，应先停止下游启动并修复。不要仅凭字面计数接近就认为可以继续。
````

### artifacts/models.gff3

````text
##gff-version 3
NC_142413.1	Gnomon	gene	16146	21098	.	-	.	ID=gene-syt4;Dbxref=GeneID:148403033,NCBIOrtholog:335357;Name=syt4;description=synaptotagmin IV;gbkey=Gene;gene=syt4;gene_biotype=protein_coding
NC_142413.1	Gnomon	mRNA	16146	21098	.	-	.	ID=rna-XM_088379294.1;Parent=gene-syt4;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;Name=XM_088379294.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;model_evidence=Supporting evidence includes similarity to: 7 Proteins%2C and 100%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 10 samples with support for all annotated introns;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	exon	20519	21098	.	-	.	ID=exon-XM_088379294.1-1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	exon	18421	18977	.	-	.	ID=exon-XM_088379294.1-2;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	exon	17523	17846	.	-	.	ID=exon-XM_088379294.1-3;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	exon	17334	17454	.	-	.	ID=exon-XM_088379294.1-4;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	exon	16146	17251	.	-	.	ID=exon-XM_088379294.1-5;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	CDS	20519	20555	.	-	0	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.101
NC_142413.1	Gnomon	CDS	18421	18977	.	-	2	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.101
NC_142413.1	Gnomon	CDS	17523	17846	.	-	0	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.101
NC_142413.1	Gnomon	CDS	17334	17454	.	-	0	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.101
NC_142413.1	Gnomon	CDS	16932	17251	.	-	2	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.101
NC_142413.1	Gnomon	gene	21247	31380	.	-	.	ID=gene-sema4f;Dbxref=GeneID:148403034,NCBIOrtholog:556003;Name=sema4f;description=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;gbkey=Gene;gene=sema4f;gene_biotype=protein_coding
NC_142413.1	Gnomon	mRNA	21247	31380	.	-	.	ID=rna-XM_088379283.1;Parent=gene-sema4f;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;Name=XM_088379283.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;model_evidence=Supporting evidence includes similarity to: 3 Proteins%2C and 100%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 29 samples with support for all annotated introns;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	30790	31380	.	-	.	ID=exon-XM_088379283.1-1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	26714	26859	.	-	.	ID=exon-XM_088379283.1-2;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	26587	26646	.	-	.	ID=exon-XM_088379283.1-3;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	26061	26162	.	-	.	ID=exon-XM_088379283.1-4;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	25864	25975	.	-	.	ID=exon-XM_088379283.1-5;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	25677	25796	.	-	.	ID=exon-XM_088379283.1-6;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	25437	25591	.	-	.	ID=exon-XM_088379283.1-7;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	25125	25306	.	-	.	ID=exon-XM_088379283.1-8;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	24901	25030	.	-	.	ID=exon-XM_088379283.1-9;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	24019	24235	.	-	.	ID=exon-XM_088379283.1-10;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	23844	23953	.	-	.	ID=exon-XM_088379283.1-11;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	23618	23769	.	-	.	ID=exon-XM_088379283.1-12;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	23393	23448	.	-	.	ID=exon-XM_088379283.1-13;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	22838	23031	.	-	.	ID=exon-XM_088379283.1-14;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	21247	22402	.	-	.	ID=exon-XM_088379283.1-15;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	CDS	30790	30880	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	26714	26859	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	26587	26646	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	26061	26162	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	25864	25975	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	25677	25796	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	25437	25591	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	25125	25306	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	24901	25030	.	-	1	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	24019	24235	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	23844	23953	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	23618	23769	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	23393	23448	.	-	1	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	22838	23031	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	21932	22402	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
````

### artifacts/proteins.faa

````text
>XP_088235409.1 semaphorin-4F [Syngnathus floridae]
MTSAGVMFACLPMCCLLLGTSRAATLSGLQYPVLSRREFGAVANFSTLLLDPASGLLFLG
ARDTIVALDTNKLNEPVRTVVWDVPQESRKTCMAKGKTEGECRNYIVLLELHSDGRHIYA
CGTHAFDPKCAYLEISSLTLRRDADGQVIVEMGRKKVPFDPRKRHTAVMIGDALYAATSI
NFRGTEFDITRATGPEQKQVRSEQNVHWLDEPDFVSSAAVALSADNNETGEDDRIYFFFN
EAAQEYNFYSKVRVPRVARVCRSDVGGLRTLQQHWTTFLKAELVCEDKVRHRRFDVLVDV
FTLRHSPGEAGTTHFYGLFTTQWEPERSAVCVFSVSDIVAAMNGPFRKGSDKSDALAPAG
LPRPGQCVNNALKAHGFDSSLKMPDNLLAYVRNHPLVQQSVNAAPLLVRKGAAYTKLAVT
LIGRREGQREEALLHLGTDSGELHQVAVLGENATLLREIPLFEATEPVNNILLYQGWVVV
GGPLSLARIQAQECALYLNCELCTRFRQLGCEWDVGKEGCVRSAAAPDHGVETEEAVRKC
DYQEAERCSPPIKELRVSLGLRVVLPCAQLSPRPCSWEHPRNSLTKQRDPDLEVTVTKDG
LGSYICACQEGQMREHTPCRRAAYHLTLEDPGTAGALSGCARHVVAFYVLVFFAGSLFGA
MLFHFASGRCEGMRRDSPDSAPPQPGSRLTDERNGIAAAEASRVRKRGNGGRLCDGLSAP
PAGDKGRNASASYANYRILSADVPDRPTAPGEGEGSEGGRAESPD
>XP_088235420.1 synaptotagmin-4 [Syngnathus floridae]
MAPVTLEDGAQPVAVPGGVAAASVFGLIFTASAFAWICCQRKNTKGQKTPPYKFVHMLKG
VDIYPESLGGKKKFAPATGVTTNKVGQTDVNGNCRSAVTPVDSPELASSPGGSRSALHLD
LEQLDLNGNFPTKPSHQLKVRRSPDLEPGTTDRREPPSPYISSHAPTPATDERKGRLGTL
RFALEYHAEKKAFIVHIQEARDLSPTDEQSLTSDPYIKLTLLPEKKHRVKTRVLRKTLDP
TFDETFSFYGIPLPSVSKLALQFMVLSFDRFSRDEIIGETLVPLSGIDLSEGRVLMSREI
IKRNVKKSWGRGELLLSLCYQSATNTLTVVVLKARHLPKNDNNGPSDPYVKVNLYHGRKR
VCKKKTHVKKCAPNPVFNEPFTFDLPSDHGPRDASVELLLMDSDPGDSRCPKPVLGRLLM
GMTAAGTAGEHWREICEHPRRQIAKWHAMSEG
````

### artifacts/record_counts.json

````text
{"cds_rows":20,"exon_rows":20,"gene_rows":2,"mrna_rows":2,"protein_records":2,"protein_residues":1217,"unique_cds_ids":2}
````

### expected.json

````text
{"acceptable_decisions":[{"observed_defect":"gff_faa_link_missing","root_cause":"id_mismatch","verdict":"block"}],"case_id":"qc_006","independent_review_status":"pending","key_evidence":[{"acceptable_pointers":["artifacts/models.gff3:9","artifacts/proteins.faa:1","artifacts/proteins.faa:15"],"claim_id":"E01","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"CDS protein_id 在本题全部 FAA 首 token 中无精确匹配；不允许改用其它标识。","verification_method":"record_connection"}],"pair_id":"NSP1","rationale":"仅审核本题声明的文件连接与层级；不推断上游运行原因或生物学质量。","root_identifiability":"confirmed","schema_version":"newsource-case-1","user_approved":false}
````

### meta.json

````text
{"case_id":"qc_006","excerpt_policy":"固定规则选两个原始完整编码gene块和所有关联完整蛋白；仅格式重排LF/FAA60列，不代表完整基因组；确定性变体逐字段记录。","historical_rule_report_seen":true,"injection_script":"bench/newsource_validation/cases.py","mechanism_exposure":"seen_in_project_development","mechanism_family":"protein_identifier_connection","pair_id":"NSP1","pressure_parent":null,"review_status":"draft","schema_version":"newsource-case-1","seed":20261011,"source_exposure":"new_to_model_prompt_tool_development","source_files":[{"path":"sources/GCF_059516105.1_RoL_Sflo_1.0_genomic.gff.gz","selection":"{\"gene_ids\": [\"gene-syt4\", \"gene-sema4f\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": {\"after\": \"XP_088235420.101\", \"attribute\": \"protein_id\", \"before\": \"XP_088235420.1\", \"policy\": \"all segments of one CDS; no other field changes\"}}","sha256":"044913a4a5458be9f427f8d3ab0d94dd0339f958195a263be075722ec4d0758c","source_group":"GCF_059516105.1","source_origin":"/home/Lianjunyang/临时/GCF_059516105.1_RoL_Sflo_1.0_genomic.gff.gz"},{"path":"sources/GCF_059516105.1_RoL_Sflo_1.0_protein.faa.gz","selection":"{\"gene_ids\": [\"gene-syt4\", \"gene-sema4f\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": {\"after\": \"XP_088235420.101\", \"attribute\": \"protein_id\", \"before\": \"XP_088235420.1\", \"policy\": \"all segments of one CDS; no other field changes\"}}","sha256":"36dcd8f4df1a97c8bf573bc0a44f6a8de2d3de4d633eac0b7260a260da8f4ccd","source_group":"GCF_059516105.1","source_origin":"/home/Lianjunyang/临时/GCF_059516105.1_RoL_Sflo_1.0_protein.faa.gz"}],"source_group":"GCF_059516105.1","split":"sealed_test","stage":"structural_annotation","synthetic":true,"type":"fault","verbatim_tool_exceptions":[],"visible_contract":{"allowed_id_mapping":"exact only","artifact_roles":{"delivery":["artifacts/models.gff3","artifacts/proteins.faa","artifacts/record_counts.json"],"reference":[]},"consumer_contract":"完整Parent层级、同序列/链、闭区间包含、protein_id精确连接FAA首token","review_target":"input","scope":"declared_subset","usable_previous_result":false}}
````


# qc_008 逐记录材料复核

私有审核补充；不是盲审、真人专家审核或模型成绩。候选答案未改、未冻结。

## 每条 CDS → FAA 精确连接

| GFF 行 | protein_id | FAA header 行 | 精确连接 |
|---|---|---|---|
| 9 | XP_088235420.1 | 15 | True |
| 10 | XP_088235420.1 | 15 | True |
| 11 | XP_088235420.1 | 15 | True |
| 12 | XP_088235420.1 | 15 | True |
| 13 | XP_088235420.1 | 15 | True |
| 31 | XP_088235409.1 | 1 | True |
| 32 | XP_088235409.1 | 1 | True |
| 33 | XP_088235409.1 | 1 | True |
| 34 | XP_088235409.1 | 1 | True |
| 35 | XP_088235409.1 | 1 | True |
| 36 | XP_088235409.1 | 1 | True |
| 37 | XP_088235409.1 | 1 | True |
| 38 | XP_088235409.1 | 1 | True |
| 39 | XP_088235409.1 | 1 | True |
| 40 | XP_088235409.1 | 1 | True |
| 41 | XP_088235409.1 | 1 | True |
| 42 | XP_088235409.1 | 1 | True |
| 43 | XP_088235409.1 | 1 | True |
| 44 | XP_088235409.1 | 1 | True |
| 45 | XP_088235409.1 | 1 | True |

## 全部直接 Parent 关系

| 子行/类型 | Parent | 父行/类型 | 子区间 | 父区间 | 序列相同 | 链相同 | 合同成立 |
|---|---|---|---|---|---|---|---|
| 3/mRNA | gene-syt4 | [2]/gene | [16146, 21098] | [16146, 21098] | True | True | True |
| 4/exon | rna-XM_088379294.1 | [3]/mRNA | [20519, 21098] | [16146, 21098] | True | True | True |
| 5/exon | rna-XM_088379294.1 | [3]/mRNA | [18421, 18977] | [16146, 21098] | True | True | True |
| 6/exon | rna-XM_088379294.1 | [3]/mRNA | [17523, 17846] | [16146, 21098] | True | True | True |
| 7/exon | rna-XM_088379294.1 | [3]/mRNA | [17334, 17454] | [16146, 21098] | True | True | True |
| 8/exon | rna-XM_088379294.1 | [3]/mRNA | [16146, 17251] | [16146, 21098] | True | True | True |
| 9/CDS | rna-XM_088379294.1 | [3]/mRNA | [20519, 20555] | [16146, 21098] | True | True | True |
| 10/CDS | rna-XM_088379294.1 | [3]/mRNA | [18421, 18977] | [16146, 21098] | True | True | True |
| 11/CDS | rna-XM_088379294.1 | [3]/mRNA | [17523, 17846] | [16146, 21098] | True | True | True |
| 12/CDS | rna-XM_088379294.1 | [3]/mRNA | [17334, 17454] | [16146, 21098] | True | True | True |
| 13/CDS | rna-XM_088379294.1 | [3]/mRNA | [16932, 17251] | [16146, 21098] | True | True | True |
| 15/mRNA | gene-sema4f | [14]/gene | [21247, 31380] | [21247, 31380] | True | True | True |
| 16/exon | rna-XM_088379283.1 | [15]/mRNA | [30790, 31380] | [21247, 31380] | True | True | True |
| 17/exon | rna-XM_088379283.1 | [15]/mRNA | [26714, 26859] | [21247, 31380] | True | True | True |
| 18/exon | rna-XM_088379283.1 | [15]/mRNA | [26587, 26646] | [21247, 31380] | True | True | True |
| 19/exon | rna-XM_088379283.1 | [15]/mRNA | [26061, 26162] | [21247, 31380] | True | True | True |
| 20/exon | rna-XM_088379283.1 | [15]/mRNA | [25864, 25975] | [21247, 31380] | True | True | True |
| 21/exon | rna-XM_088379283.1 | [15]/mRNA | [25677, 25796] | [21247, 31380] | True | True | True |
| 22/exon | rna-XM_088379283.1 | [15]/mRNA | [25437, 25591] | [21247, 31380] | True | True | True |
| 23/exon | rna-XM_088379283.1 | [15]/mRNA | [25125, 25306] | [21247, 31380] | True | True | True |
| 24/exon | rna-XM_088379283.1 | [15]/mRNA | [24901, 25030] | [21247, 31380] | True | True | True |
| 25/exon | rna-XM_088379283.1 | [15]/mRNA | [24019, 24235] | [21247, 31380] | True | True | True |
| 26/exon | rna-XM_088379283.1 | [15]/mRNA | [23844, 23953] | [21247, 31380] | True | True | True |
| 27/exon | rna-XM_088379283.1 | [15]/mRNA | [23618, 23769] | [21247, 31380] | True | True | True |
| 28/exon | rna-XM_088379283.1 | [15]/mRNA | [23393, 23448] | [21247, 31380] | True | True | True |
| 29/exon | rna-XM_088379283.1 | [15]/mRNA | [22838, 23031] | [21247, 31380] | True | True | True |
| 30/exon | rna-XM_088379283.1 | [15]/mRNA | [21247, 22402] | [21247, 31380] | True | True | True |
| 31/CDS | rna-XM_088379283.1 | [15]/mRNA | [30790, 30880] | [21247, 31380] | True | True | True |
| 32/CDS | rna-XM_088379283.1 | [15]/mRNA | [26714, 26859] | [21247, 31380] | True | True | True |
| 33/CDS | rna-XM_088379283.1 | [15]/mRNA | [26587, 26646] | [21247, 31380] | True | True | True |
| 34/CDS | rna-XM_088379283.1 | [15]/mRNA | [26061, 26162] | [21247, 31380] | True | True | True |
| 35/CDS | rna-XM_088379283.1 | [15]/mRNA | [25864, 25975] | [21247, 31380] | True | True | True |
| 36/CDS | rna-XM_088379283.1 | [15]/mRNA | [25677, 25796] | [21247, 31380] | True | True | True |
| 37/CDS | rna-XM_088379283.1 | [15]/mRNA | [25437, 25591] | [21247, 31380] | True | True | True |
| 38/CDS | rna-XM_088379283.1 | [15]/mRNA | [25125, 25306] | [21247, 31380] | True | True | True |
| 39/CDS | rna-XM_088379283.1 | [15]/mRNA | [24901, 25030] | [21247, 31380] | True | True | True |
| 40/CDS | rna-XM_088379283.1 | [15]/mRNA | [24019, 24235] | [21247, 31380] | True | True | True |
| 41/CDS | rna-XM_088379283.1 | [15]/mRNA | [23844, 23953] | [21247, 31380] | True | True | True |
| 42/CDS | rna-XM_088379283.1 | [15]/mRNA | [23618, 23769] | [21247, 31380] | True | True | True |
| 43/CDS | rna-XM_088379283.1 | [15]/mRNA | [23393, 23448] | [21247, 31380] | True | True | True |
| 44/CDS | rna-XM_088379283.1 | [15]/mRNA | [22838, 23031] | [21247, 31380] | True | True | True |
| 45/CDS | rna-XM_088379283.1 | [15]/mRNA | [21932, 22402] | [21247, 31380] | True | True | True |

## 候选引用逐项定位

### E01

每个不同 CDS protein_id 与完整 FAA 的首 token 精确接续；逐个 ID 验证，不以行数代替。

- artifacts/models.gff3:9

```text
NC_142413.1	Gnomon	CDS	20519	20555	.	-	0	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.1
```

- artifacts/models.gff3:10

```text
NC_142413.1	Gnomon	CDS	18421	18977	.	-	2	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.1
```

- artifacts/models.gff3:11

```text
NC_142413.1	Gnomon	CDS	17523	17846	.	-	0	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.1
```

- artifacts/models.gff3:12

```text
NC_142413.1	Gnomon	CDS	17334	17454	.	-	0	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.1
```

- artifacts/models.gff3:13

```text
NC_142413.1	Gnomon	CDS	16932	17251	.	-	2	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.1
```

- artifacts/models.gff3:31

```text
NC_142413.1	Gnomon	CDS	30790	30880	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:32

```text
NC_142413.1	Gnomon	CDS	26714	26859	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:33

```text
NC_142413.1	Gnomon	CDS	26587	26646	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:34

```text
NC_142413.1	Gnomon	CDS	26061	26162	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:35

```text
NC_142413.1	Gnomon	CDS	25864	25975	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:36

```text
NC_142413.1	Gnomon	CDS	25677	25796	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:37

```text
NC_142413.1	Gnomon	CDS	25437	25591	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:38

```text
NC_142413.1	Gnomon	CDS	25125	25306	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:39

```text
NC_142413.1	Gnomon	CDS	24901	25030	.	-	1	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:40

```text
NC_142413.1	Gnomon	CDS	24019	24235	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:41

```text
NC_142413.1	Gnomon	CDS	23844	23953	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:42

```text
NC_142413.1	Gnomon	CDS	23618	23769	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:43

```text
NC_142413.1	Gnomon	CDS	23393	23448	.	-	1	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:44

```text
NC_142413.1	Gnomon	CDS	22838	23031	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/models.gff3:45

```text
NC_142413.1	Gnomon	CDS	21932	22402	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
```

- artifacts/proteins.faa:1

```text
>XP_088235409.1 semaphorin-4F [Syngnathus floridae]
```

- artifacts/proteins.faa:15

```text
>XP_088235420.1 synaptotagmin-4 [Syngnathus floridae]
```

### E02

所有 Parent 接续且类型、序列/链与父子闭区间符合题面必要合同。

- artifacts/models.gff3:2

```text
NC_142413.1	Gnomon	gene	16146	21098	.	-	.	ID=gene-syt4;Dbxref=GeneID:148403033,NCBIOrtholog:335357;Name=syt4;description=synaptotagmin IV;gbkey=Gene;gene=syt4;gene_biotype=protein_coding
```

- artifacts/models.gff3:3

```text
NC_142413.1	Gnomon	mRNA	16146	21098	.	-	.	ID=rna-XM_088379294.1;Parent=gene-syt4;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;Name=XM_088379294.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;model_evidence=Supporting evidence includes similarity to: 7 Proteins%2C and 100%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 10 samples with support for all annotated introns;product=synaptotagmin IV;transcript_id=XM_088379294.1
```

- artifacts/models.gff3:14

```text
NC_142413.1	Gnomon	gene	21247	31380	.	-	.	ID=gene-sema4f;Dbxref=GeneID:148403034,NCBIOrtholog:556003;Name=sema4f;description=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;gbkey=Gene;gene=sema4f;gene_biotype=protein_coding
```

- artifacts/models.gff3:15

```text
NC_142413.1	Gnomon	mRNA	21247	31380	.	-	.	ID=rna-XM_088379283.1;Parent=gene-sema4f;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;Name=XM_088379283.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;model_evidence=Supporting evidence includes similarity to: 3 Proteins%2C and 100%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 29 samples with support for all annotated introns;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
```

原候选是代表性定位；完成全记录核对还需要以下行。此处补充材料，不修改 expected.json：

artifacts/models.gff3:4, artifacts/models.gff3:5, artifacts/models.gff3:6, artifacts/models.gff3:7, artifacts/models.gff3:8, artifacts/models.gff3:9, artifacts/models.gff3:10, artifacts/models.gff3:11, artifacts/models.gff3:12, artifacts/models.gff3:13, artifacts/models.gff3:16, artifacts/models.gff3:17, artifacts/models.gff3:18, artifacts/models.gff3:19, artifacts/models.gff3:20, artifacts/models.gff3:21, artifacts/models.gff3:22, artifacts/models.gff3:23, artifacts/models.gff3:24, artifacts/models.gff3:25, artifacts/models.gff3:26, artifacts/models.gff3:27, artifacts/models.gff3:28, artifacts/models.gff3:29, artifacts/models.gff3:30, artifacts/models.gff3:31, artifacts/models.gff3:32, artifacts/models.gff3:33, artifacts/models.gff3:34, artifacts/models.gff3:35, artifacts/models.gff3:36, artifacts/models.gff3:37, artifacts/models.gff3:38, artifacts/models.gff3:39, artifacts/models.gff3:40, artifacts/models.gff3:41, artifacts/models.gff3:42, artifacts/models.gff3:43, artifacts/models.gff3:44, artifacts/models.gff3:45

## 完整公开题目与候选答案

以下逐文件原文供复核。代码框行号与文件自身的行号不同，请以原始附件或上面的 pointer 为准。

### task.md

````text
# 下游输入审核

请审核Syngnathus floridae的一组结构注释记录是否可以交给下游文件连接程序。输出统一规定的JSON。

本题审核输入文件，不是已完成的分析交付；没有提供可回退的旧版本。审核范围仅为给出的两套完整编码gene特征块及对应蛋白，不能外推全基因组注释质量。models.gff3是本次输入，proteins.faa是按ID查找序列的输入；record_counts.json仅列字面计数。

消费者读取GFF的Parent建立gene→mRNA→exon/CDS关系，并按每行CDS的protein_id精确查找FAA header第一个token。每个Parent必须在本题完整记录中存在且类型符合上述层级；子记录必须与父记录同seqid、同链，闭区间完全位于父记录内。FAA记录与不同protein_id对应的一组CDS一一相接。没有声明去版本号、改大小写、以Name或CDS ID代替protein_id等映射。

同一CDS的多片段可以重复ID，不能把CDS行数当蛋白条数。允许异构体和partial=true，不检查模型全长、翻译正确性或生物学功能；这些属性不豁免上述文件连接要求。除必要输入合同外，本题没有其它继续条件，也没有提供运行日志来解释上游过程。

请根据公开记录检查必要合同，并建议最小修复或补证。满足所有必要输入要求时可继续；必要连接或层级要求不能满足时，应先停止下游启动并修复。不要仅凭字面计数接近就认为可以继续。
````

### artifacts/models.gff3

````text
##gff-version 3
NC_142413.1	Gnomon	gene	16146	21098	.	-	.	ID=gene-syt4;Dbxref=GeneID:148403033,NCBIOrtholog:335357;Name=syt4;description=synaptotagmin IV;gbkey=Gene;gene=syt4;gene_biotype=protein_coding
NC_142413.1	Gnomon	mRNA	16146	21098	.	-	.	ID=rna-XM_088379294.1;Parent=gene-syt4;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;Name=XM_088379294.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;model_evidence=Supporting evidence includes similarity to: 7 Proteins%2C and 100%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 10 samples with support for all annotated introns;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	exon	20519	21098	.	-	.	ID=exon-XM_088379294.1-1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	exon	18421	18977	.	-	.	ID=exon-XM_088379294.1-2;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	exon	17523	17846	.	-	.	ID=exon-XM_088379294.1-3;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	exon	17334	17454	.	-	.	ID=exon-XM_088379294.1-4;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	exon	16146	17251	.	-	.	ID=exon-XM_088379294.1-5;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XM_088379294.1,NCBIOrtholog:335357;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=syt4;product=synaptotagmin IV;transcript_id=XM_088379294.1
NC_142413.1	Gnomon	CDS	20519	20555	.	-	0	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.1
NC_142413.1	Gnomon	CDS	18421	18977	.	-	2	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.1
NC_142413.1	Gnomon	CDS	17523	17846	.	-	0	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.1
NC_142413.1	Gnomon	CDS	17334	17454	.	-	0	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.1
NC_142413.1	Gnomon	CDS	16932	17251	.	-	2	ID=cds-XP_088235420.1;Parent=rna-XM_088379294.1;Dbxref=GeneID:148403033,GenBank:XP_088235420.1,NCBIOrtholog:335357;Name=XP_088235420.1;gbkey=CDS;gene=syt4;product=synaptotagmin-4;protein_id=XP_088235420.1
NC_142413.1	Gnomon	gene	21247	31380	.	-	.	ID=gene-sema4f;Dbxref=GeneID:148403034,NCBIOrtholog:556003;Name=sema4f;description=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;gbkey=Gene;gene=sema4f;gene_biotype=protein_coding
NC_142413.1	Gnomon	mRNA	21247	31380	.	-	.	ID=rna-XM_088379283.1;Parent=gene-sema4f;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;Name=XM_088379283.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;model_evidence=Supporting evidence includes similarity to: 3 Proteins%2C and 100%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 29 samples with support for all annotated introns;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	30790	31380	.	-	.	ID=exon-XM_088379283.1-1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	26714	26859	.	-	.	ID=exon-XM_088379283.1-2;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	26587	26646	.	-	.	ID=exon-XM_088379283.1-3;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	26061	26162	.	-	.	ID=exon-XM_088379283.1-4;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	25864	25975	.	-	.	ID=exon-XM_088379283.1-5;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	25677	25796	.	-	.	ID=exon-XM_088379283.1-6;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	25437	25591	.	-	.	ID=exon-XM_088379283.1-7;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	25125	25306	.	-	.	ID=exon-XM_088379283.1-8;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	24901	25030	.	-	.	ID=exon-XM_088379283.1-9;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	24019	24235	.	-	.	ID=exon-XM_088379283.1-10;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	23844	23953	.	-	.	ID=exon-XM_088379283.1-11;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	23618	23769	.	-	.	ID=exon-XM_088379283.1-12;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	23393	23448	.	-	.	ID=exon-XM_088379283.1-13;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	22838	23031	.	-	.	ID=exon-XM_088379283.1-14;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	exon	21247	22402	.	-	.	ID=exon-XM_088379283.1-15;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XM_088379283.1,NCBIOrtholog:556003;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=sema4f;product=sema domain%2C immunoglobulin domain (Ig)%2C transmembrane domain (TM) and short cytoplasmic domain%2C (semaphorin) 4F;transcript_id=XM_088379283.1
NC_142413.1	Gnomon	CDS	30790	30880	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	26714	26859	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	26587	26646	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	26061	26162	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	25864	25975	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	25677	25796	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	25437	25591	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	25125	25306	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	24901	25030	.	-	1	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	24019	24235	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	23844	23953	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	23618	23769	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	23393	23448	.	-	1	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	22838	23031	.	-	2	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
NC_142413.1	Gnomon	CDS	21932	22402	.	-	0	ID=cds-XP_088235409.1;Parent=rna-XM_088379283.1;Dbxref=GeneID:148403034,GenBank:XP_088235409.1,NCBIOrtholog:556003;Name=XP_088235409.1;gbkey=CDS;gene=sema4f;product=semaphorin-4F;protein_id=XP_088235409.1
````

### artifacts/proteins.faa

````text
>XP_088235409.1 semaphorin-4F [Syngnathus floridae]
MTSAGVMFACLPMCCLLLGTSRAATLSGLQYPVLSRREFGAVANFSTLLLDPASGLLFLG
ARDTIVALDTNKLNEPVRTVVWDVPQESRKTCMAKGKTEGECRNYIVLLELHSDGRHIYA
CGTHAFDPKCAYLEISSLTLRRDADGQVIVEMGRKKVPFDPRKRHTAVMIGDALYAATSI
NFRGTEFDITRATGPEQKQVRSEQNVHWLDEPDFVSSAAVALSADNNETGEDDRIYFFFN
EAAQEYNFYSKVRVPRVARVCRSDVGGLRTLQQHWTTFLKAELVCEDKVRHRRFDVLVDV
FTLRHSPGEAGTTHFYGLFTTQWEPERSAVCVFSVSDIVAAMNGPFRKGSDKSDALAPAG
LPRPGQCVNNALKAHGFDSSLKMPDNLLAYVRNHPLVQQSVNAAPLLVRKGAAYTKLAVT
LIGRREGQREEALLHLGTDSGELHQVAVLGENATLLREIPLFEATEPVNNILLYQGWVVV
GGPLSLARIQAQECALYLNCELCTRFRQLGCEWDVGKEGCVRSAAAPDHGVETEEAVRKC
DYQEAERCSPPIKELRVSLGLRVVLPCAQLSPRPCSWEHPRNSLTKQRDPDLEVTVTKDG
LGSYICACQEGQMREHTPCRRAAYHLTLEDPGTAGALSGCARHVVAFYVLVFFAGSLFGA
MLFHFASGRCEGMRRDSPDSAPPQPGSRLTDERNGIAAAEASRVRKRGNGGRLCDGLSAP
PAGDKGRNASASYANYRILSADVPDRPTAPGEGEGSEGGRAESPD
>XP_088235420.1 synaptotagmin-4 [Syngnathus floridae]
MAPVTLEDGAQPVAVPGGVAAASVFGLIFTASAFAWICCQRKNTKGQKTPPYKFVHMLKG
VDIYPESLGGKKKFAPATGVTTNKVGQTDVNGNCRSAVTPVDSPELASSPGGSRSALHLD
LEQLDLNGNFPTKPSHQLKVRRSPDLEPGTTDRREPPSPYISSHAPTPATDERKGRLGTL
RFALEYHAEKKAFIVHIQEARDLSPTDEQSLTSDPYIKLTLLPEKKHRVKTRVLRKTLDP
TFDETFSFYGIPLPSVSKLALQFMVLSFDRFSRDEIIGETLVPLSGIDLSEGRVLMSREI
IKRNVKKSWGRGELLLSLCYQSATNTLTVVVLKARHLPKNDNNGPSDPYVKVNLYHGRKR
VCKKKTHVKKCAPNPVFNEPFTFDLPSDHGPRDASVELLLMDSDPGDSRCPKPVLGRLLM
GMTAAGTAGEHWREICEHPRRQIAKWHAMSEG
````

### artifacts/record_counts.json

````text
{"cds_rows":20,"exon_rows":20,"gene_rows":2,"mrna_rows":2,"protein_records":2,"protein_residues":1217,"unique_cds_ids":2}
````

### expected.json

````text
{"acceptable_decisions":[{"observed_defect":"none","root_cause":"none","verdict":"pass"}],"case_id":"qc_008","independent_review_status":"pending","key_evidence":[{"acceptable_pointers":["artifacts/models.gff3:9","artifacts/models.gff3:10","artifacts/models.gff3:11","artifacts/models.gff3:12","artifacts/models.gff3:13","artifacts/models.gff3:31","artifacts/models.gff3:32","artifacts/models.gff3:33","artifacts/models.gff3:34","artifacts/models.gff3:35","artifacts/models.gff3:36","artifacts/models.gff3:37","artifacts/models.gff3:38","artifacts/models.gff3:39","artifacts/models.gff3:40","artifacts/models.gff3:41","artifacts/models.gff3:42","artifacts/models.gff3:43","artifacts/models.gff3:44","artifacts/models.gff3:45","artifacts/proteins.faa:1","artifacts/proteins.faa:15"],"claim_id":"E01","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"每个不同 CDS protein_id 与完整 FAA 的首 token 精确接续；逐个 ID 验证，不以行数代替。","verification_method":"record_connection"},{"acceptable_pointers":["artifacts/models.gff3:2","artifacts/models.gff3:3","artifacts/models.gff3:14","artifacts/models.gff3:15"],"claim_id":"E02","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"所有 Parent 接续且类型、序列/链与父子闭区间符合题面必要合同。","verification_method":"record_connection"}],"pair_id":"NSP1","rationale":"仅审核本题声明的文件连接与层级；不推断上游运行原因或生物学质量。","root_identifiability":"no_defect","schema_version":"newsource-case-1","user_approved":false}
````

### meta.json

````text
{"case_id":"qc_008","excerpt_policy":"固定规则选两个原始完整编码gene块和所有关联完整蛋白；仅格式重排LF/FAA60列，不代表完整基因组；确定性变体逐字段记录。","historical_rule_report_seen":true,"injection_script":"bench/newsource_validation/cases.py","mechanism_exposure":"seen_in_project_development","mechanism_family":"protein_identifier_connection","pair_id":"NSP1","pressure_parent":null,"review_status":"draft","schema_version":"newsource-case-1","seed":20261011,"source_exposure":"new_to_model_prompt_tool_development","source_files":[{"path":"sources/GCF_059516105.1_RoL_Sflo_1.0_genomic.gff.gz","selection":"{\"gene_ids\": [\"gene-syt4\", \"gene-sema4f\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": \"unmodified source subset\"}","sha256":"044913a4a5458be9f427f8d3ab0d94dd0339f958195a263be075722ec4d0758c","source_group":"GCF_059516105.1","source_origin":"/home/Lianjunyang/临时/GCF_059516105.1_RoL_Sflo_1.0_genomic.gff.gz"},{"path":"sources/GCF_059516105.1_RoL_Sflo_1.0_protein.faa.gz","selection":"{\"gene_ids\": [\"gene-syt4\", \"gene-sema4f\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": \"unmodified source subset\"}","sha256":"36dcd8f4df1a97c8bf573bc0a44f6a8de2d3de4d633eac0b7260a260da8f4ccd","source_group":"GCF_059516105.1","source_origin":"/home/Lianjunyang/临时/GCF_059516105.1_RoL_Sflo_1.0_protein.faa.gz"}],"source_group":"GCF_059516105.1","split":"sealed_test","stage":"structural_annotation","synthetic":true,"type":"normal","verbatim_tool_exceptions":[],"visible_contract":{"allowed_id_mapping":"exact only","artifact_roles":{"delivery":["artifacts/models.gff3","artifacts/proteins.faa","artifacts/record_counts.json"],"reference":[]},"consumer_contract":"完整Parent层级、同序列/链、闭区间包含、protein_id精确连接FAA首token","review_target":"input","scope":"declared_subset","usable_previous_result":false}}
````
