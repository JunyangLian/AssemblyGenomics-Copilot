# NSP4 完整配对审核材料

有答案的材料复核；不能作为盲审。两题均需独立读取原文。

# qc_001 逐记录材料复核

私有审核补充；不是盲审、真人专家审核或模型成绩。候选答案未改、未冻结。

## 每条 CDS → FAA 精确连接

| GFF 行 | protein_id | FAA header 行 | 精确连接 |
|---|---|---|---|
| 8 | XP_056650550.101 | None | False |
| 9 | XP_056650550.101 | None | False |
| 10 | XP_056650550.101 | None | False |
| 11 | XP_056650550.101 | None | False |
| 19 | XP_056650623.1 | 17 | True |
| 20 | XP_056650623.1 | 17 | True |
| 21 | XP_056650623.1 | 17 | True |
| 22 | XP_056650623.1 | 17 | True |
| 29 | XP_056650626.1 | 23 | True |
| 30 | XP_056650626.1 | 23 | True |
| 31 | XP_056650626.1 | 23 | True |
| 32 | XP_056650626.1 | 23 | True |
| 39 | XP_085194108.1 | 29 | True |
| 40 | XP_085194108.1 | 29 | True |
| 41 | XP_085194108.1 | 29 | True |

## 全部直接 Parent 关系

| 子行/类型 | Parent | 父行/类型 | 子区间 | 父区间 | 序列相同 | 链相同 | 合同成立 |
|---|---|---|---|---|---|---|---|
| 3/mRNA | gene-LOC130453517 | [2]/gene | [538344, 561838] | [538344, 561838] | True | True | True |
| 4/exon | rna-XM_056794572.2 | [3]/mRNA | [561475, 561838] | [538344, 561838] | True | True | True |
| 5/exon | rna-XM_056794572.2 | [3]/mRNA | [543965, 544091] | [538344, 561838] | True | True | True |
| 6/exon | rna-XM_056794572.2 | [3]/mRNA | [543373, 543471] | [538344, 561838] | True | True | True |
| 7/exon | rna-XM_056794572.2 | [3]/mRNA | [538344, 542460] | [538344, 561838] | True | True | True |
| 8/CDS | rna-XM_056794572.2 | [3]/mRNA | [561475, 561534] | [538344, 561838] | True | True | True |
| 9/CDS | rna-XM_056794572.2 | [3]/mRNA | [543965, 544091] | [538344, 561838] | True | True | True |
| 10/CDS | rna-XM_056794572.2 | [3]/mRNA | [543373, 543471] | [538344, 561838] | True | True | True |
| 11/CDS | rna-XM_056794572.2 | [3]/mRNA | [540218, 542460] | [538344, 561838] | True | True | True |
| 13/mRNA | gene-LOC130453802 | [12]/gene | [584462, 593327] | [584462, 593327] | True | True | True |
| 14/exon | rna-XM_056794645.2 | [13]/mRNA | [593118, 593327] | [584462, 593327] | True | True | True |
| 15/exon | rna-XM_056794645.2 | [13]/mRNA | [592207, 592294] | [584462, 593327] | True | True | True |
| 16/exon | rna-XM_056794645.2 | [13]/mRNA | [590746, 590872] | [584462, 593327] | True | True | True |
| 17/exon | rna-XM_056794645.2 | [13]/mRNA | [590143, 590241] | [584462, 593327] | True | True | True |
| 18/exon | rna-XM_056794645.2 | [13]/mRNA | [584462, 589230] | [584462, 593327] | True | True | True |
| 19/CDS | rna-XM_056794645.2 | [13]/mRNA | [592207, 592266] | [584462, 593327] | True | True | True |
| 20/CDS | rna-XM_056794645.2 | [13]/mRNA | [590746, 590872] | [584462, 593327] | True | True | True |
| 21/CDS | rna-XM_056794645.2 | [13]/mRNA | [590143, 590241] | [584462, 593327] | True | True | True |
| 22/CDS | rna-XM_056794645.2 | [13]/mRNA | [588671, 589230] | [584462, 593327] | True | True | True |
| 23/mRNA | gene-LOC130453802 | [12]/gene | [584462, 592964] | [584462, 593327] | True | True | True |
| 24/exon | rna-XM_056794648.2 | [23]/mRNA | [592854, 592964] | [584462, 592964] | True | True | True |
| 25/exon | rna-XM_056794648.2 | [23]/mRNA | [592207, 592294] | [584462, 592964] | True | True | True |
| 26/exon | rna-XM_056794648.2 | [23]/mRNA | [590746, 590872] | [584462, 592964] | True | True | True |
| 27/exon | rna-XM_056794648.2 | [23]/mRNA | [590143, 590241] | [584462, 592964] | True | True | True |
| 28/exon | rna-XM_056794648.2 | [23]/mRNA | [584462, 589230] | [584462, 592964] | True | True | True |
| 29/CDS | rna-XM_056794648.2 | [23]/mRNA | [592207, 592266] | [584462, 592964] | True | True | True |
| 30/CDS | rna-XM_056794648.2 | [23]/mRNA | [590746, 590872] | [584462, 592964] | True | True | True |
| 31/CDS | rna-XM_056794648.2 | [23]/mRNA | [590143, 590241] | [584462, 592964] | True | True | True |
| 32/CDS | rna-XM_056794648.2 | [23]/mRNA | [588671, 589230] | [584462, 592964] | True | True | True |
| 33/mRNA | gene-LOC130453802 | [12]/gene | [584462, 592964] | [584462, 593327] | True | True | True |
| 34/exon | rna-XM_085337982.1 | [33]/mRNA | [592854, 592964] | [584462, 592964] | True | True | True |
| 35/exon | rna-XM_085337982.1 | [33]/mRNA | [592207, 592294] | [584462, 592964] | True | True | True |
| 36/exon | rna-XM_085337982.1 | [33]/mRNA | [590746, 590872] | [584462, 592964] | True | True | True |
| 37/exon | rna-XM_085337982.1 | [33]/mRNA | [589934, 590241] | [584462, 592964] | True | True | True |
| 38/exon | rna-XM_085337982.1 | [33]/mRNA | [584462, 589230] | [584462, 592964] | True | True | True |
| 39/CDS | rna-XM_085337982.1 | [33]/mRNA | [592207, 592266] | [584462, 592964] | True | True | True |
| 40/CDS | rna-XM_085337982.1 | [33]/mRNA | [590746, 590872] | [584462, 592964] | True | True | True |
| 41/CDS | rna-XM_085337982.1 | [33]/mRNA | [590135, 590241] | [584462, 592964] | True | True | True |

## 候选引用逐项定位

### E01

CDS protein_id 在本题全部 FAA 首 token 中无精确匹配；不允许改用其它标识。

- artifacts/models.gff3:8

```text
NC_077227.1	Gnomon	CDS	561475	561534	.	-	0	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.101
```

- artifacts/proteins.faa:1

```text
>XP_056650550.1 uncharacterized protein LOC130453517 [Monodelphis domestica]
```

- artifacts/proteins.faa:17

```text
>XP_056650623.1 zinc finger protein 184-like isoform X1 [Monodelphis domestica]
```

- artifacts/proteins.faa:23

```text
>XP_056650626.1 zinc finger protein 184-like isoform X1 [Monodelphis domestica]
```

- artifacts/proteins.faa:29

```text
>XP_085194108.1 putative postmeiotic segregation increased 2-like protein 3 isoform X2 [Monodelphis domestica]
```

原候选是代表性定位；完成全记录核对还需要以下行。此处补充材料，不修改 expected.json：

artifacts/models.gff3:9, artifacts/models.gff3:10, artifacts/models.gff3:11

## 完整公开题目与候选答案

以下逐文件原文供复核。代码框行号与文件自身的行号不同，请以原始附件或上面的 pointer 为准。

### task.md

````text
# 下游输入审核

请审核Monodelphis domestica的一组结构注释记录是否可以交给下游文件连接程序。输出统一规定的JSON。

本题审核输入文件，不是已完成的分析交付；没有提供可回退的旧版本。审核范围仅为给出的两套完整编码gene特征块及对应蛋白，不能外推全基因组注释质量。models.gff3是本次输入，proteins.faa是按ID查找序列的输入；record_counts.json仅列字面计数。

消费者读取GFF的Parent建立gene→mRNA→exon/CDS关系，并按每行CDS的protein_id精确查找FAA header第一个token。每个Parent必须在本题完整记录中存在且类型符合上述层级；子记录必须与父记录同seqid、同链，闭区间完全位于父记录内。FAA记录与不同protein_id对应的一组CDS一一相接。没有声明去版本号、改大小写、以Name或CDS ID代替protein_id等映射。

同一CDS的多片段可以重复ID，不能把CDS行数当蛋白条数。允许异构体和partial=true，不检查模型全长、翻译正确性或生物学功能；这些属性不豁免上述文件连接要求。除必要输入合同外，本题没有其它继续条件，也没有提供运行日志来解释上游过程。

请根据公开记录检查必要合同，并建议最小修复或补证。满足所有必要输入要求时可继续；必要连接或层级要求不能满足时，应先停止下游启动并修复。不要仅凭字面计数接近就认为可以继续。
````

### artifacts/models.gff3

````text
##gff-version 3
NC_077227.1	Gnomon	gene	538344	561838	.	-	.	ID=gene-LOC130453517;Dbxref=GeneID:130453517;Name=LOC130453517;description=uncharacterized LOC130453517;gbkey=Gene;gene=LOC130453517;gene_biotype=protein_coding
NC_077227.1	Gnomon	mRNA	538344	561838	.	-	.	ID=rna-XM_056794572.2;Parent=gene-LOC130453517;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;Name=XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;model_evidence=Supporting evidence includes similarity to: 8 Proteins%2C 3 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 42 samples with support for all annotated introns;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
NC_077227.1	Gnomon	exon	561475	561838	.	-	.	ID=exon-XM_056794572.2-1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
NC_077227.1	Gnomon	exon	543965	544091	.	-	.	ID=exon-XM_056794572.2-2;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
NC_077227.1	Gnomon	exon	543373	543471	.	-	.	ID=exon-XM_056794572.2-3;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
NC_077227.1	Gnomon	exon	538344	542460	.	-	.	ID=exon-XM_056794572.2-4;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
NC_077227.1	Gnomon	CDS	561475	561534	.	-	0	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.101
NC_077227.1	Gnomon	CDS	543965	544091	.	-	0	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.101
NC_077227.1	Gnomon	CDS	543373	543471	.	-	2	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.101
NC_077227.1	Gnomon	CDS	540218	542460	.	-	2	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.101
NC_077227.1	Gnomon	gene	584462	593327	.	-	.	ID=gene-LOC130453802;Dbxref=GeneID:130453802;Name=LOC130453802;description=putative postmeiotic segregation increased 2-like protein 3;gbkey=Gene;gene=LOC130453802;gene_biotype=protein_coding
NC_077227.1	Gnomon	mRNA	584462	593327	.	-	.	ID=rna-XM_056794645.2;Parent=gene-LOC130453802;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;Name=XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;model_evidence=Supporting evidence includes similarity to: 1 Protein%2C 8 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 45 samples with support for all annotated introns;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	exon	593118	593327	.	-	.	ID=exon-XM_056794645.2-1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	exon	592207	592294	.	-	.	ID=exon-XM_056794645.2-2;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	exon	590746	590872	.	-	.	ID=exon-XM_056794645.2-3;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	exon	590143	590241	.	-	.	ID=exon-XM_056794645.2-4;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	exon	584462	589230	.	-	.	ID=exon-XM_056794645.2-5;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	CDS	592207	592266	.	-	0	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
NC_077227.1	Gnomon	CDS	590746	590872	.	-	0	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
NC_077227.1	Gnomon	CDS	590143	590241	.	-	2	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
NC_077227.1	Gnomon	CDS	588671	589230	.	-	2	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
NC_077227.1	Gnomon	mRNA	584462	592964	.	-	.	ID=rna-XM_056794648.2;Parent=gene-LOC130453802;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;Name=XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;model_evidence=Supporting evidence includes similarity to: 1 Protein%2C 15 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 54 samples with support for all annotated introns;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	exon	592854	592964	.	-	.	ID=exon-XM_056794648.2-1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	exon	592207	592294	.	-	.	ID=exon-XM_056794648.2-2;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	exon	590746	590872	.	-	.	ID=exon-XM_056794648.2-3;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	exon	590143	590241	.	-	.	ID=exon-XM_056794648.2-4;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	exon	584462	589230	.	-	.	ID=exon-XM_056794648.2-5;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	CDS	592207	592266	.	-	0	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
NC_077227.1	Gnomon	CDS	590746	590872	.	-	0	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
NC_077227.1	Gnomon	CDS	590143	590241	.	-	2	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
NC_077227.1	Gnomon	CDS	588671	589230	.	-	2	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
NC_077227.1	Gnomon	mRNA	584462	592964	.	-	.	ID=rna-XM_085337982.1;Parent=gene-LOC130453802;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;Name=XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;model_evidence=Supporting evidence includes similarity to: 5 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 26 samples with support for all annotated introns;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	exon	592854	592964	.	-	.	ID=exon-XM_085337982.1-1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	exon	592207	592294	.	-	.	ID=exon-XM_085337982.1-2;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	exon	590746	590872	.	-	.	ID=exon-XM_085337982.1-3;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	exon	589934	590241	.	-	.	ID=exon-XM_085337982.1-4;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	exon	584462	589230	.	-	.	ID=exon-XM_085337982.1-5;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	CDS	592207	592266	.	-	0	ID=cds-XP_085194108.1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XP_085194108.1;Name=XP_085194108.1;gbkey=CDS;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3 isoform X2;protein_id=XP_085194108.1
NC_077227.1	Gnomon	CDS	590746	590872	.	-	0	ID=cds-XP_085194108.1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XP_085194108.1;Name=XP_085194108.1;gbkey=CDS;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3 isoform X2;protein_id=XP_085194108.1
NC_077227.1	Gnomon	CDS	590135	590241	.	-	2	ID=cds-XP_085194108.1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XP_085194108.1;Name=XP_085194108.1;gbkey=CDS;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3 isoform X2;protein_id=XP_085194108.1
````

### artifacts/proteins.faa

````text
>XP_056650550.1 uncharacterized protein LOC130453517 [Monodelphis domestica]
MESLEECGEDAALEPCRTPQASVTFKDVAVDFTWEEWRLLDPPQKELFWEVMLENYRNLV
CLGLADSNKDVRISELESGEPHWIPTGGVLRSCWPGWESRLQTKESAPKMSISVKVLSQE
KFLEDDLRICKMAKTWECDGRLKKKESMEGKPSRGIKIIQAEPPNEAGGSAYDKYSQTSS
PEPGLFPQQGASVVMQGQKGDNQRGSSTMYLNQGQSDQIHSRKKRRNKVTKCQKVLGHDL
GSIKKRGILSEEKVHERGNSFPRINECGPHQTTDRGKECNELTKWRKTGRAKLYSRCQSR
ERRYKCSECGKAFQQKGDLKRHYRIHTGEKPFKCSECGKAFSSAGTLKRHQSTHTGEKPF
GCSECGKTFGRNSHLLSHQRRIHGVIKLYECNVCGKAFSRKYDLTTHSSIHAGEKPFECS
ECGKAFSRARTLKQHQSTHTGEKPFKCSECGKAFLQKEALKRHYRIHTGEKPFKCSECGK
AFQHKEALKRHYRIHTGEKPFECSECGKAFQHKGVLKIHYRIHTGEKAFKCSECGKAFLH
KGALKRHYRIHTGEKAFKCSECGKAFQEKGALKIHYRIHTGEKPFKCSECGKAFQQKGAL
KIHYRIHTGEKPFECSECGKAFQHKEALKRHYRIHTGEKPFECSECGKAFSRAGTLKQHQ
STHTGEKPFKCSDCGRAFLQKEALKRHYRIHTGEKPFECSECGKAFRRNSHLLSHQRTIH
GEIKRHECNVCGKAFSRKYDLTTHSSIHTGEKPFECSECGKAFSSKSYFTHHSRIHAGEK
PFQCDICGKVLLSKFNLNHHQKTHIEEKPFLCSVCGKGFPGKKTLTAHQRTHAGKRTSEC
SE
>XP_056650623.1 zinc finger protein 184-like isoform X1 [Monodelphis domestica]
MESLEECGEGTGLEPCKTPHASVTFKDVAVDFTWEEWRLLDPPQKELFWEVMLENYRNLV
CLGLADSNKDVRISELESGEPHWIPTGGVLRSCWPGWESRLQTKESAPKMSISVKVLSQE
KFLEDDLRICKMEKAWECDGRLKRKQRMEGKPSRGIKIIQAEPPNEAGGSAYDKYSQTSS
PEPGLFPQQGASVVMQGQKGDNQRGRSTMYLNQGQSDQIHSRKKRRNKVTKCQKVLGHDL
GCIKNVEFFLKRKFMKGRIHSLVLMNVVHTRQLIGGKSVMS
>XP_056650626.1 zinc finger protein 184-like isoform X1 [Monodelphis domestica]
MESLEECGEGTGLEPCKTPHASVTFKDVAVDFTWEEWRLLDPPQKELFWEVMLENYRNLV
CLGLADSNKDVRISELESGEPHWIPTGGVLRSCWPGWESRLQTKESAPKMSISVKVLSQE
KFLEDDLRICKMEKAWECDGRLKRKQRMEGKPSRGIKIIQAEPPNEAGGSAYDKYSQTSS
PEPGLFPQQGASVVMQGQKGDNQRGRSTMYLNQGQSDQIHSRKKRRNKVTKCQKVLGHDL
GCIKNVEFFLKRKFMKGRIHSLVLMNVVHTRQLIGGKSVMS
>XP_085194108.1 putative postmeiotic segregation increased 2-like protein 3 isoform X2 [Monodelphis domestica]
MESLEECGEGTGLEPCKTPHASVTFKDVAVDFTWEEWRLLDPPQKELFWEVMLENYRNLV
CLGLADSNKDVRISELESGEPHWIPTGGVLRSCWPGE
````

### artifacts/record_counts.json

````text
{"cds_rows":15,"exon_rows":19,"gene_rows":2,"mrna_rows":4,"protein_records":4,"protein_residues":1501,"unique_cds_ids":4}
````

### expected.json

````text
{"acceptable_decisions":[{"observed_defect":"gff_faa_link_missing","root_cause":"id_mismatch","verdict":"block"}],"case_id":"qc_001","independent_review_status":"pending","key_evidence":[{"acceptable_pointers":["artifacts/models.gff3:8","artifacts/proteins.faa:1","artifacts/proteins.faa:17","artifacts/proteins.faa:23","artifacts/proteins.faa:29"],"claim_id":"E01","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"CDS protein_id 在本题全部 FAA 首 token 中无精确匹配；不允许改用其它标识。","verification_method":"record_connection"}],"pair_id":"NSP4","rationale":"仅审核本题声明的文件连接与层级；不推断上游运行原因或生物学质量。","root_identifiability":"confirmed","schema_version":"newsource-case-1","user_approved":false}
````

### meta.json

````text
{"case_id":"qc_001","excerpt_policy":"固定规则选两个原始完整编码gene块和所有关联完整蛋白；仅格式重排LF/FAA60列，不代表完整基因组；确定性变体逐字段记录。","historical_rule_report_seen":true,"injection_script":"bench/newsource_validation/cases.py","mechanism_exposure":"seen_in_project_development","mechanism_family":"protein_identifier_connection","pair_id":"NSP4","pressure_parent":null,"review_status":"draft","schema_version":"newsource-case-1","seed":20261011,"source_exposure":"new_to_model_prompt_tool_development","source_files":[{"path":"sources/GCF_027887165.2_mMonDom1.pri_genomic.gff.gz","selection":"{\"gene_ids\": [\"gene-LOC130453517\", \"gene-LOC130453802\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": {\"after\": \"XP_056650550.101\", \"attribute\": \"protein_id\", \"before\": \"XP_056650550.1\", \"policy\": \"all segments of one CDS; no other field changes\"}}","sha256":"b2e2dea345ed4e390159dd9f2ca5db95203a8c9210d9dbdef218dc23f07755fd","source_group":"GCF_027887165.2","source_origin":"/home/Lianjunyang/临时/GCF_027887165.2_mMonDom1.pri_genomic.gff.gz"},{"path":"sources/GCF_027887165.2_mMonDom1.pri_protein.faa.gz","selection":"{\"gene_ids\": [\"gene-LOC130453517\", \"gene-LOC130453802\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": {\"after\": \"XP_056650550.101\", \"attribute\": \"protein_id\", \"before\": \"XP_056650550.1\", \"policy\": \"all segments of one CDS; no other field changes\"}}","sha256":"4ae6d4f54b75f20f748daac68994762af2a43b1fde4fc9c9b774d4a9ebb47a41","source_group":"GCF_027887165.2","source_origin":"/home/Lianjunyang/临时/GCF_027887165.2_mMonDom1.pri_protein.faa.gz"}],"source_group":"GCF_027887165.2","split":"sealed_test","stage":"structural_annotation","synthetic":true,"type":"fault","verbatim_tool_exceptions":[],"visible_contract":{"allowed_id_mapping":"exact only","artifact_roles":{"delivery":["artifacts/models.gff3","artifacts/proteins.faa","artifacts/record_counts.json"],"reference":[]},"consumer_contract":"完整Parent层级、同序列/链、闭区间包含、protein_id精确连接FAA首token","review_target":"input","scope":"declared_subset","usable_previous_result":false}}
````


# qc_011 逐记录材料复核

私有审核补充；不是盲审、真人专家审核或模型成绩。候选答案未改、未冻结。

## 每条 CDS → FAA 精确连接

| GFF 行 | protein_id | FAA header 行 | 精确连接 |
|---|---|---|---|
| 8 | XP_056650550.1 | 1 | True |
| 9 | XP_056650550.1 | 1 | True |
| 10 | XP_056650550.1 | 1 | True |
| 11 | XP_056650550.1 | 1 | True |
| 19 | XP_056650623.1 | 17 | True |
| 20 | XP_056650623.1 | 17 | True |
| 21 | XP_056650623.1 | 17 | True |
| 22 | XP_056650623.1 | 17 | True |
| 29 | XP_056650626.1 | 23 | True |
| 30 | XP_056650626.1 | 23 | True |
| 31 | XP_056650626.1 | 23 | True |
| 32 | XP_056650626.1 | 23 | True |
| 39 | XP_085194108.1 | 29 | True |
| 40 | XP_085194108.1 | 29 | True |
| 41 | XP_085194108.1 | 29 | True |

## 全部直接 Parent 关系

| 子行/类型 | Parent | 父行/类型 | 子区间 | 父区间 | 序列相同 | 链相同 | 合同成立 |
|---|---|---|---|---|---|---|---|
| 3/mRNA | gene-LOC130453517 | [2]/gene | [538344, 561838] | [538344, 561838] | True | True | True |
| 4/exon | rna-XM_056794572.2 | [3]/mRNA | [561475, 561838] | [538344, 561838] | True | True | True |
| 5/exon | rna-XM_056794572.2 | [3]/mRNA | [543965, 544091] | [538344, 561838] | True | True | True |
| 6/exon | rna-XM_056794572.2 | [3]/mRNA | [543373, 543471] | [538344, 561838] | True | True | True |
| 7/exon | rna-XM_056794572.2 | [3]/mRNA | [538344, 542460] | [538344, 561838] | True | True | True |
| 8/CDS | rna-XM_056794572.2 | [3]/mRNA | [561475, 561534] | [538344, 561838] | True | True | True |
| 9/CDS | rna-XM_056794572.2 | [3]/mRNA | [543965, 544091] | [538344, 561838] | True | True | True |
| 10/CDS | rna-XM_056794572.2 | [3]/mRNA | [543373, 543471] | [538344, 561838] | True | True | True |
| 11/CDS | rna-XM_056794572.2 | [3]/mRNA | [540218, 542460] | [538344, 561838] | True | True | True |
| 13/mRNA | gene-LOC130453802 | [12]/gene | [584462, 593327] | [584462, 593327] | True | True | True |
| 14/exon | rna-XM_056794645.2 | [13]/mRNA | [593118, 593327] | [584462, 593327] | True | True | True |
| 15/exon | rna-XM_056794645.2 | [13]/mRNA | [592207, 592294] | [584462, 593327] | True | True | True |
| 16/exon | rna-XM_056794645.2 | [13]/mRNA | [590746, 590872] | [584462, 593327] | True | True | True |
| 17/exon | rna-XM_056794645.2 | [13]/mRNA | [590143, 590241] | [584462, 593327] | True | True | True |
| 18/exon | rna-XM_056794645.2 | [13]/mRNA | [584462, 589230] | [584462, 593327] | True | True | True |
| 19/CDS | rna-XM_056794645.2 | [13]/mRNA | [592207, 592266] | [584462, 593327] | True | True | True |
| 20/CDS | rna-XM_056794645.2 | [13]/mRNA | [590746, 590872] | [584462, 593327] | True | True | True |
| 21/CDS | rna-XM_056794645.2 | [13]/mRNA | [590143, 590241] | [584462, 593327] | True | True | True |
| 22/CDS | rna-XM_056794645.2 | [13]/mRNA | [588671, 589230] | [584462, 593327] | True | True | True |
| 23/mRNA | gene-LOC130453802 | [12]/gene | [584462, 592964] | [584462, 593327] | True | True | True |
| 24/exon | rna-XM_056794648.2 | [23]/mRNA | [592854, 592964] | [584462, 592964] | True | True | True |
| 25/exon | rna-XM_056794648.2 | [23]/mRNA | [592207, 592294] | [584462, 592964] | True | True | True |
| 26/exon | rna-XM_056794648.2 | [23]/mRNA | [590746, 590872] | [584462, 592964] | True | True | True |
| 27/exon | rna-XM_056794648.2 | [23]/mRNA | [590143, 590241] | [584462, 592964] | True | True | True |
| 28/exon | rna-XM_056794648.2 | [23]/mRNA | [584462, 589230] | [584462, 592964] | True | True | True |
| 29/CDS | rna-XM_056794648.2 | [23]/mRNA | [592207, 592266] | [584462, 592964] | True | True | True |
| 30/CDS | rna-XM_056794648.2 | [23]/mRNA | [590746, 590872] | [584462, 592964] | True | True | True |
| 31/CDS | rna-XM_056794648.2 | [23]/mRNA | [590143, 590241] | [584462, 592964] | True | True | True |
| 32/CDS | rna-XM_056794648.2 | [23]/mRNA | [588671, 589230] | [584462, 592964] | True | True | True |
| 33/mRNA | gene-LOC130453802 | [12]/gene | [584462, 592964] | [584462, 593327] | True | True | True |
| 34/exon | rna-XM_085337982.1 | [33]/mRNA | [592854, 592964] | [584462, 592964] | True | True | True |
| 35/exon | rna-XM_085337982.1 | [33]/mRNA | [592207, 592294] | [584462, 592964] | True | True | True |
| 36/exon | rna-XM_085337982.1 | [33]/mRNA | [590746, 590872] | [584462, 592964] | True | True | True |
| 37/exon | rna-XM_085337982.1 | [33]/mRNA | [589934, 590241] | [584462, 592964] | True | True | True |
| 38/exon | rna-XM_085337982.1 | [33]/mRNA | [584462, 589230] | [584462, 592964] | True | True | True |
| 39/CDS | rna-XM_085337982.1 | [33]/mRNA | [592207, 592266] | [584462, 592964] | True | True | True |
| 40/CDS | rna-XM_085337982.1 | [33]/mRNA | [590746, 590872] | [584462, 592964] | True | True | True |
| 41/CDS | rna-XM_085337982.1 | [33]/mRNA | [590135, 590241] | [584462, 592964] | True | True | True |

## 候选引用逐项定位

### E01

每个不同 CDS protein_id 与完整 FAA 的首 token 精确接续；逐个 ID 验证，不以行数代替。

- artifacts/models.gff3:8

```text
NC_077227.1	Gnomon	CDS	561475	561534	.	-	0	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.1
```

- artifacts/models.gff3:9

```text
NC_077227.1	Gnomon	CDS	543965	544091	.	-	0	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.1
```

- artifacts/models.gff3:10

```text
NC_077227.1	Gnomon	CDS	543373	543471	.	-	2	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.1
```

- artifacts/models.gff3:11

```text
NC_077227.1	Gnomon	CDS	540218	542460	.	-	2	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.1
```

- artifacts/models.gff3:19

```text
NC_077227.1	Gnomon	CDS	592207	592266	.	-	0	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
```

- artifacts/models.gff3:20

```text
NC_077227.1	Gnomon	CDS	590746	590872	.	-	0	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
```

- artifacts/models.gff3:21

```text
NC_077227.1	Gnomon	CDS	590143	590241	.	-	2	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
```

- artifacts/models.gff3:22

```text
NC_077227.1	Gnomon	CDS	588671	589230	.	-	2	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
```

- artifacts/models.gff3:29

```text
NC_077227.1	Gnomon	CDS	592207	592266	.	-	0	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
```

- artifacts/models.gff3:30

```text
NC_077227.1	Gnomon	CDS	590746	590872	.	-	0	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
```

- artifacts/models.gff3:31

```text
NC_077227.1	Gnomon	CDS	590143	590241	.	-	2	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
```

- artifacts/models.gff3:32

```text
NC_077227.1	Gnomon	CDS	588671	589230	.	-	2	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
```

- artifacts/models.gff3:39

```text
NC_077227.1	Gnomon	CDS	592207	592266	.	-	0	ID=cds-XP_085194108.1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XP_085194108.1;Name=XP_085194108.1;gbkey=CDS;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3 isoform X2;protein_id=XP_085194108.1
```

- artifacts/models.gff3:40

```text
NC_077227.1	Gnomon	CDS	590746	590872	.	-	0	ID=cds-XP_085194108.1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XP_085194108.1;Name=XP_085194108.1;gbkey=CDS;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3 isoform X2;protein_id=XP_085194108.1
```

- artifacts/models.gff3:41

```text
NC_077227.1	Gnomon	CDS	590135	590241	.	-	2	ID=cds-XP_085194108.1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XP_085194108.1;Name=XP_085194108.1;gbkey=CDS;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3 isoform X2;protein_id=XP_085194108.1
```

- artifacts/proteins.faa:1

```text
>XP_056650550.1 uncharacterized protein LOC130453517 [Monodelphis domestica]
```

- artifacts/proteins.faa:17

```text
>XP_056650623.1 zinc finger protein 184-like isoform X1 [Monodelphis domestica]
```

- artifacts/proteins.faa:23

```text
>XP_056650626.1 zinc finger protein 184-like isoform X1 [Monodelphis domestica]
```

- artifacts/proteins.faa:29

```text
>XP_085194108.1 putative postmeiotic segregation increased 2-like protein 3 isoform X2 [Monodelphis domestica]
```

### E02

所有 Parent 接续且类型、序列/链与父子闭区间符合题面必要合同。

- artifacts/models.gff3:2

```text
NC_077227.1	Gnomon	gene	538344	561838	.	-	.	ID=gene-LOC130453517;Dbxref=GeneID:130453517;Name=LOC130453517;description=uncharacterized LOC130453517;gbkey=Gene;gene=LOC130453517;gene_biotype=protein_coding
```

- artifacts/models.gff3:3

```text
NC_077227.1	Gnomon	mRNA	538344	561838	.	-	.	ID=rna-XM_056794572.2;Parent=gene-LOC130453517;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;Name=XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;model_evidence=Supporting evidence includes similarity to: 8 Proteins%2C 3 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 42 samples with support for all annotated introns;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
```

- artifacts/models.gff3:12

```text
NC_077227.1	Gnomon	gene	584462	593327	.	-	.	ID=gene-LOC130453802;Dbxref=GeneID:130453802;Name=LOC130453802;description=putative postmeiotic segregation increased 2-like protein 3;gbkey=Gene;gene=LOC130453802;gene_biotype=protein_coding
```

- artifacts/models.gff3:13

```text
NC_077227.1	Gnomon	mRNA	584462	593327	.	-	.	ID=rna-XM_056794645.2;Parent=gene-LOC130453802;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;Name=XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;model_evidence=Supporting evidence includes similarity to: 1 Protein%2C 8 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 45 samples with support for all annotated introns;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
```

- artifacts/models.gff3:23

```text
NC_077227.1	Gnomon	mRNA	584462	592964	.	-	.	ID=rna-XM_056794648.2;Parent=gene-LOC130453802;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;Name=XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;model_evidence=Supporting evidence includes similarity to: 1 Protein%2C 15 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 54 samples with support for all annotated introns;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
```

- artifacts/models.gff3:33

```text
NC_077227.1	Gnomon	mRNA	584462	592964	.	-	.	ID=rna-XM_085337982.1;Parent=gene-LOC130453802;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;Name=XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;model_evidence=Supporting evidence includes similarity to: 5 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 26 samples with support for all annotated introns;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
```

原候选是代表性定位；完成全记录核对还需要以下行。此处补充材料，不修改 expected.json：

artifacts/models.gff3:4, artifacts/models.gff3:5, artifacts/models.gff3:6, artifacts/models.gff3:7, artifacts/models.gff3:8, artifacts/models.gff3:9, artifacts/models.gff3:10, artifacts/models.gff3:11, artifacts/models.gff3:14, artifacts/models.gff3:15, artifacts/models.gff3:16, artifacts/models.gff3:17, artifacts/models.gff3:18, artifacts/models.gff3:19, artifacts/models.gff3:20, artifacts/models.gff3:21, artifacts/models.gff3:22, artifacts/models.gff3:24, artifacts/models.gff3:25, artifacts/models.gff3:26, artifacts/models.gff3:27, artifacts/models.gff3:28, artifacts/models.gff3:29, artifacts/models.gff3:30, artifacts/models.gff3:31, artifacts/models.gff3:32, artifacts/models.gff3:34, artifacts/models.gff3:35, artifacts/models.gff3:36, artifacts/models.gff3:37, artifacts/models.gff3:38, artifacts/models.gff3:39, artifacts/models.gff3:40, artifacts/models.gff3:41

## 完整公开题目与候选答案

以下逐文件原文供复核。代码框行号与文件自身的行号不同，请以原始附件或上面的 pointer 为准。

### task.md

````text
# 下游输入审核

请审核Monodelphis domestica的一组结构注释记录是否可以交给下游文件连接程序。输出统一规定的JSON。

本题审核输入文件，不是已完成的分析交付；没有提供可回退的旧版本。审核范围仅为给出的两套完整编码gene特征块及对应蛋白，不能外推全基因组注释质量。models.gff3是本次输入，proteins.faa是按ID查找序列的输入；record_counts.json仅列字面计数。

消费者读取GFF的Parent建立gene→mRNA→exon/CDS关系，并按每行CDS的protein_id精确查找FAA header第一个token。每个Parent必须在本题完整记录中存在且类型符合上述层级；子记录必须与父记录同seqid、同链，闭区间完全位于父记录内。FAA记录与不同protein_id对应的一组CDS一一相接。没有声明去版本号、改大小写、以Name或CDS ID代替protein_id等映射。

同一CDS的多片段可以重复ID，不能把CDS行数当蛋白条数。允许异构体和partial=true，不检查模型全长、翻译正确性或生物学功能；这些属性不豁免上述文件连接要求。除必要输入合同外，本题没有其它继续条件，也没有提供运行日志来解释上游过程。

请根据公开记录检查必要合同，并建议最小修复或补证。满足所有必要输入要求时可继续；必要连接或层级要求不能满足时，应先停止下游启动并修复。不要仅凭字面计数接近就认为可以继续。
````

### artifacts/models.gff3

````text
##gff-version 3
NC_077227.1	Gnomon	gene	538344	561838	.	-	.	ID=gene-LOC130453517;Dbxref=GeneID:130453517;Name=LOC130453517;description=uncharacterized LOC130453517;gbkey=Gene;gene=LOC130453517;gene_biotype=protein_coding
NC_077227.1	Gnomon	mRNA	538344	561838	.	-	.	ID=rna-XM_056794572.2;Parent=gene-LOC130453517;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;Name=XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;model_evidence=Supporting evidence includes similarity to: 8 Proteins%2C 3 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 42 samples with support for all annotated introns;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
NC_077227.1	Gnomon	exon	561475	561838	.	-	.	ID=exon-XM_056794572.2-1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
NC_077227.1	Gnomon	exon	543965	544091	.	-	.	ID=exon-XM_056794572.2-2;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
NC_077227.1	Gnomon	exon	543373	543471	.	-	.	ID=exon-XM_056794572.2-3;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
NC_077227.1	Gnomon	exon	538344	542460	.	-	.	ID=exon-XM_056794572.2-4;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XM_056794572.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453517;product=uncharacterized LOC130453517;transcript_id=XM_056794572.2
NC_077227.1	Gnomon	CDS	561475	561534	.	-	0	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.1
NC_077227.1	Gnomon	CDS	543965	544091	.	-	0	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.1
NC_077227.1	Gnomon	CDS	543373	543471	.	-	2	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.1
NC_077227.1	Gnomon	CDS	540218	542460	.	-	2	ID=cds-XP_056650550.1;Parent=rna-XM_056794572.2;Dbxref=GeneID:130453517,GenBank:XP_056650550.1;Name=XP_056650550.1;gbkey=CDS;gene=LOC130453517;product=uncharacterized protein LOC130453517;protein_id=XP_056650550.1
NC_077227.1	Gnomon	gene	584462	593327	.	-	.	ID=gene-LOC130453802;Dbxref=GeneID:130453802;Name=LOC130453802;description=putative postmeiotic segregation increased 2-like protein 3;gbkey=Gene;gene=LOC130453802;gene_biotype=protein_coding
NC_077227.1	Gnomon	mRNA	584462	593327	.	-	.	ID=rna-XM_056794645.2;Parent=gene-LOC130453802;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;Name=XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;model_evidence=Supporting evidence includes similarity to: 1 Protein%2C 8 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 45 samples with support for all annotated introns;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	exon	593118	593327	.	-	.	ID=exon-XM_056794645.2-1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	exon	592207	592294	.	-	.	ID=exon-XM_056794645.2-2;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	exon	590746	590872	.	-	.	ID=exon-XM_056794645.2-3;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	exon	590143	590241	.	-	.	ID=exon-XM_056794645.2-4;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	exon	584462	589230	.	-	.	ID=exon-XM_056794645.2-5;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XM_056794645.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X2;transcript_id=XM_056794645.2
NC_077227.1	Gnomon	CDS	592207	592266	.	-	0	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
NC_077227.1	Gnomon	CDS	590746	590872	.	-	0	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
NC_077227.1	Gnomon	CDS	590143	590241	.	-	2	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
NC_077227.1	Gnomon	CDS	588671	589230	.	-	2	ID=cds-XP_056650623.1;Parent=rna-XM_056794645.2;Dbxref=GeneID:130453802,GenBank:XP_056650623.1;Name=XP_056650623.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650623.1
NC_077227.1	Gnomon	mRNA	584462	592964	.	-	.	ID=rna-XM_056794648.2;Parent=gene-LOC130453802;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;Name=XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;model_evidence=Supporting evidence includes similarity to: 1 Protein%2C 15 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 54 samples with support for all annotated introns;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	exon	592854	592964	.	-	.	ID=exon-XM_056794648.2-1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	exon	592207	592294	.	-	.	ID=exon-XM_056794648.2-2;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	exon	590746	590872	.	-	.	ID=exon-XM_056794648.2-3;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	exon	590143	590241	.	-	.	ID=exon-XM_056794648.2-4;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	exon	584462	589230	.	-	.	ID=exon-XM_056794648.2-5;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XM_056794648.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X1;transcript_id=XM_056794648.2
NC_077227.1	Gnomon	CDS	592207	592266	.	-	0	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
NC_077227.1	Gnomon	CDS	590746	590872	.	-	0	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
NC_077227.1	Gnomon	CDS	590143	590241	.	-	2	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
NC_077227.1	Gnomon	CDS	588671	589230	.	-	2	ID=cds-XP_056650626.1;Parent=rna-XM_056794648.2;Dbxref=GeneID:130453802,GenBank:XP_056650626.1;Name=XP_056650626.1;gbkey=CDS;gene=LOC130453802;product=zinc finger protein 184-like isoform X1;protein_id=XP_056650626.1
NC_077227.1	Gnomon	mRNA	584462	592964	.	-	.	ID=rna-XM_085337982.1;Parent=gene-LOC130453802;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;Name=XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;model_evidence=Supporting evidence includes similarity to: 5 long SRA reads%2C and 99%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 26 samples with support for all annotated introns;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	exon	592854	592964	.	-	.	ID=exon-XM_085337982.1-1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	exon	592207	592294	.	-	.	ID=exon-XM_085337982.1-2;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	exon	590746	590872	.	-	.	ID=exon-XM_085337982.1-3;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	exon	589934	590241	.	-	.	ID=exon-XM_085337982.1-4;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	exon	584462	589230	.	-	.	ID=exon-XM_085337982.1-5;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XM_085337982.1;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3%2C transcript variant X3;transcript_id=XM_085337982.1
NC_077227.1	Gnomon	CDS	592207	592266	.	-	0	ID=cds-XP_085194108.1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XP_085194108.1;Name=XP_085194108.1;gbkey=CDS;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3 isoform X2;protein_id=XP_085194108.1
NC_077227.1	Gnomon	CDS	590746	590872	.	-	0	ID=cds-XP_085194108.1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XP_085194108.1;Name=XP_085194108.1;gbkey=CDS;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3 isoform X2;protein_id=XP_085194108.1
NC_077227.1	Gnomon	CDS	590135	590241	.	-	2	ID=cds-XP_085194108.1;Parent=rna-XM_085337982.1;Dbxref=GeneID:130453802,GenBank:XP_085194108.1;Name=XP_085194108.1;gbkey=CDS;gene=LOC130453802;product=putative postmeiotic segregation increased 2-like protein 3 isoform X2;protein_id=XP_085194108.1
````

### artifacts/proteins.faa

````text
>XP_056650550.1 uncharacterized protein LOC130453517 [Monodelphis domestica]
MESLEECGEDAALEPCRTPQASVTFKDVAVDFTWEEWRLLDPPQKELFWEVMLENYRNLV
CLGLADSNKDVRISELESGEPHWIPTGGVLRSCWPGWESRLQTKESAPKMSISVKVLSQE
KFLEDDLRICKMAKTWECDGRLKKKESMEGKPSRGIKIIQAEPPNEAGGSAYDKYSQTSS
PEPGLFPQQGASVVMQGQKGDNQRGSSTMYLNQGQSDQIHSRKKRRNKVTKCQKVLGHDL
GSIKKRGILSEEKVHERGNSFPRINECGPHQTTDRGKECNELTKWRKTGRAKLYSRCQSR
ERRYKCSECGKAFQQKGDLKRHYRIHTGEKPFKCSECGKAFSSAGTLKRHQSTHTGEKPF
GCSECGKTFGRNSHLLSHQRRIHGVIKLYECNVCGKAFSRKYDLTTHSSIHAGEKPFECS
ECGKAFSRARTLKQHQSTHTGEKPFKCSECGKAFLQKEALKRHYRIHTGEKPFKCSECGK
AFQHKEALKRHYRIHTGEKPFECSECGKAFQHKGVLKIHYRIHTGEKAFKCSECGKAFLH
KGALKRHYRIHTGEKAFKCSECGKAFQEKGALKIHYRIHTGEKPFKCSECGKAFQQKGAL
KIHYRIHTGEKPFECSECGKAFQHKEALKRHYRIHTGEKPFECSECGKAFSRAGTLKQHQ
STHTGEKPFKCSDCGRAFLQKEALKRHYRIHTGEKPFECSECGKAFRRNSHLLSHQRTIH
GEIKRHECNVCGKAFSRKYDLTTHSSIHTGEKPFECSECGKAFSSKSYFTHHSRIHAGEK
PFQCDICGKVLLSKFNLNHHQKTHIEEKPFLCSVCGKGFPGKKTLTAHQRTHAGKRTSEC
SE
>XP_056650623.1 zinc finger protein 184-like isoform X1 [Monodelphis domestica]
MESLEECGEGTGLEPCKTPHASVTFKDVAVDFTWEEWRLLDPPQKELFWEVMLENYRNLV
CLGLADSNKDVRISELESGEPHWIPTGGVLRSCWPGWESRLQTKESAPKMSISVKVLSQE
KFLEDDLRICKMEKAWECDGRLKRKQRMEGKPSRGIKIIQAEPPNEAGGSAYDKYSQTSS
PEPGLFPQQGASVVMQGQKGDNQRGRSTMYLNQGQSDQIHSRKKRRNKVTKCQKVLGHDL
GCIKNVEFFLKRKFMKGRIHSLVLMNVVHTRQLIGGKSVMS
>XP_056650626.1 zinc finger protein 184-like isoform X1 [Monodelphis domestica]
MESLEECGEGTGLEPCKTPHASVTFKDVAVDFTWEEWRLLDPPQKELFWEVMLENYRNLV
CLGLADSNKDVRISELESGEPHWIPTGGVLRSCWPGWESRLQTKESAPKMSISVKVLSQE
KFLEDDLRICKMEKAWECDGRLKRKQRMEGKPSRGIKIIQAEPPNEAGGSAYDKYSQTSS
PEPGLFPQQGASVVMQGQKGDNQRGRSTMYLNQGQSDQIHSRKKRRNKVTKCQKVLGHDL
GCIKNVEFFLKRKFMKGRIHSLVLMNVVHTRQLIGGKSVMS
>XP_085194108.1 putative postmeiotic segregation increased 2-like protein 3 isoform X2 [Monodelphis domestica]
MESLEECGEGTGLEPCKTPHASVTFKDVAVDFTWEEWRLLDPPQKELFWEVMLENYRNLV
CLGLADSNKDVRISELESGEPHWIPTGGVLRSCWPGE
````

### artifacts/record_counts.json

````text
{"cds_rows":15,"exon_rows":19,"gene_rows":2,"mrna_rows":4,"protein_records":4,"protein_residues":1501,"unique_cds_ids":4}
````

### expected.json

````text
{"acceptable_decisions":[{"observed_defect":"none","root_cause":"none","verdict":"pass"}],"case_id":"qc_011","independent_review_status":"pending","key_evidence":[{"acceptable_pointers":["artifacts/models.gff3:8","artifacts/models.gff3:9","artifacts/models.gff3:10","artifacts/models.gff3:11","artifacts/models.gff3:19","artifacts/models.gff3:20","artifacts/models.gff3:21","artifacts/models.gff3:22","artifacts/models.gff3:29","artifacts/models.gff3:30","artifacts/models.gff3:31","artifacts/models.gff3:32","artifacts/models.gff3:39","artifacts/models.gff3:40","artifacts/models.gff3:41","artifacts/proteins.faa:1","artifacts/proteins.faa:17","artifacts/proteins.faa:23","artifacts/proteins.faa:29"],"claim_id":"E01","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"每个不同 CDS protein_id 与完整 FAA 的首 token 精确接续；逐个 ID 验证，不以行数代替。","verification_method":"record_connection"},{"acceptable_pointers":["artifacts/models.gff3:2","artifacts/models.gff3:3","artifacts/models.gff3:12","artifacts/models.gff3:13","artifacts/models.gff3:23","artifacts/models.gff3:33"],"claim_id":"E02","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"所有 Parent 接续且类型、序列/链与父子闭区间符合题面必要合同。","verification_method":"record_connection"}],"pair_id":"NSP4","rationale":"仅审核本题声明的文件连接与层级；不推断上游运行原因或生物学质量。","root_identifiability":"no_defect","schema_version":"newsource-case-1","user_approved":false}
````

### meta.json

````text
{"case_id":"qc_011","excerpt_policy":"固定规则选两个原始完整编码gene块和所有关联完整蛋白；仅格式重排LF/FAA60列，不代表完整基因组；确定性变体逐字段记录。","historical_rule_report_seen":true,"injection_script":"bench/newsource_validation/cases.py","mechanism_exposure":"seen_in_project_development","mechanism_family":"protein_identifier_connection","pair_id":"NSP4","pressure_parent":null,"review_status":"draft","schema_version":"newsource-case-1","seed":20261011,"source_exposure":"new_to_model_prompt_tool_development","source_files":[{"path":"sources/GCF_027887165.2_mMonDom1.pri_genomic.gff.gz","selection":"{\"gene_ids\": [\"gene-LOC130453517\", \"gene-LOC130453802\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": \"unmodified source subset\"}","sha256":"b2e2dea345ed4e390159dd9f2ca5db95203a8c9210d9dbdef218dc23f07755fd","source_group":"GCF_027887165.2","source_origin":"/home/Lianjunyang/临时/GCF_027887165.2_mMonDom1.pri_genomic.gff.gz"},{"path":"sources/GCF_027887165.2_mMonDom1.pri_protein.faa.gz","selection":"{\"gene_ids\": [\"gene-LOC130453517\", \"gene-LOC130453802\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": \"unmodified source subset\"}","sha256":"4ae6d4f54b75f20f748daac68994762af2a43b1fde4fc9c9b774d4a9ebb47a41","source_group":"GCF_027887165.2","source_origin":"/home/Lianjunyang/临时/GCF_027887165.2_mMonDom1.pri_protein.faa.gz"}],"source_group":"GCF_027887165.2","split":"sealed_test","stage":"structural_annotation","synthetic":true,"type":"normal","verbatim_tool_exceptions":[],"visible_contract":{"allowed_id_mapping":"exact only","artifact_roles":{"delivery":["artifacts/models.gff3","artifacts/proteins.faa","artifacts/record_counts.json"],"reference":[]},"consumer_contract":"完整Parent层级、同序列/链、闭区间包含、protein_id精确连接FAA首token","review_target":"input","scope":"declared_subset","usable_previous_result":false}}
````
