# NSP6 完整配对审核材料

有答案的材料复核；不能作为盲审。两题均需独立读取原文。

# qc_002 逐记录材料复核

私有审核补充；不是盲审、真人专家审核或模型成绩。候选答案未改、未冻结。

## 每条 CDS → FAA 精确连接

| GFF 行 | protein_id | FAA header 行 | 精确连接 |
|---|---|---|---|
| 10 | XP_007046407.3 | 1 | True |
| 11 | XP_007046407.3 | 1 | True |
| 12 | XP_007046407.3 | 1 | True |
| 13 | XP_007046407.3 | 1 | True |
| 14 | XP_007046407.3 | 1 | True |
| 22 | XP_017973981.2 | 6 | True |
| 23 | XP_017973981.2 | 6 | True |
| 24 | XP_017973981.2 | 6 | True |
| 25 | XP_017973981.2 | 6 | True |
| 26 | XP_017973981.2 | 6 | True |
| 33 | XP_088664204.1 | 10 | True |
| 34 | XP_088664204.1 | 10 | True |
| 35 | XP_088664204.1 | 10 | True |
| 36 | XP_088664204.1 | 10 | True |

## 全部直接 Parent 关系

| 子行/类型 | Parent | 父行/类型 | 子区间 | 父区间 | 序列相同 | 链相同 | 合同成立 |
|---|---|---|---|---|---|---|---|
| 3/mRNA | gene-CBSX3 | [2]/gene | [25281, 27766] | [25281, 27766] | True | True | True |
| 4/exon | rna-XM_007046345.3 | [3]/mRNA | [25281, 25430] | [25281, 27766] | True | True | True |
| 5/exon | rna-XM_007046345.3 | [3]/mRNA | [26284, 26546] | [25281, 27766] | True | True | True |
| 6/exon | rna-XM_007046345.3 | [3]/mRNA | [26633, 26714] | [25281, 27766] | True | True | True |
| 7/exon | rna-XM_007046345.3 | [3]/mRNA | [27131, 27204] | [25281, 27766] | True | True | True |
| 8/exon | rna-XM_007046345.3 | [3]/mRNA | [27292, 27352] | [25281, 27766] | True | True | True |
| 9/exon | rna-XM_007046345.3 | [3]/mRNA | [27443, 27766] | [25281, 27766] | True | True | True |
| 10/CDS | rna-XM_007046345.3 | [3]/mRNA | [26289, 26546] | [25281, 27766] | True | True | True |
| 11/CDS | rna-XM_007046345.3 | [3]/mRNA | [26633, 26714] | [25281, 27766] | True | True | True |
| 12/CDS | rna-XM_007046345.3 | [3]/mRNA | [27131, 27204] | [25281, 27766] | True | True | True |
| 13/CDS | rna-XM_007046345.3 | [3]/mRNA | [27292, 27352] | [25281, 27766] | True | True | True |
| 14/CDS | rna-XM_007046345.3 | [3]/mRNA | [27443, 27585] | [25281, 27766] | True | True | True |
| 15/mRNA | gene-CBSX3 | [2]/gene | [25290, 27708] | [25281, 27766] | True | True | True |
| 16/exon | rna-XM_018118492.2 | [15]/mRNA | [25290, 25430] | [25290, 27708] | True | True | True |
| 17/exon | rna-XM_018118492.2 | [15]/mRNA | [26284, 26546] | [25290, 27708] | True | True | True |
| 18/exon | rna-XM_018118492.2 | [15]/mRNA | [26633, 26714] | [25290, 27708] | True | True | True |
| 19/exon | rna-XM_018118492.2 | [15]/mRNA | [27131, 27204] | [25290, 27708] | True | True | True |
| 20/exon | rna-XM_018118492.2 | [15]/mRNA | [27292, 27352] | [25290, 27708] | True | True | True |
| 21/exon | rna-XM_018118492.2 | [15]/mRNA | [27432, 27708] | [25290, 27708] | True | True | True |
| 22/CDS | rna-XM_018118492.2 | [15]/mRNA | [26289, 26546] | [25290, 27708] | True | True | True |
| 23/CDS | rna-XM_018118492.2 | [15]/mRNA | [26633, 26714] | [25290, 27708] | True | True | True |
| 24/CDS | rna-XM_018118492.2 | [15]/mRNA | [27131, 27204] | [25290, 27708] | True | True | True |
| 25/CDS | rna-XM_018118492.2 | [15]/mRNA | [27292, 27352] | [25290, 27708] | True | True | True |
| 26/CDS | rna-XM_018118492.2 | [15]/mRNA | [27432, 27469] | [25290, 27708] | True | True | True |
| 28/mRNA | gene-LOC148764400 | [27]/gene | [66080, 68156] | [66080, 68156] | True | True | True |
| 29/exon | rna-XM_088808078.1 | [28]/mRNA | [66080, 66300] | [66080, 68156] | True | True | True |
| 30/exon | rna-XM_088808078.1 | [28]/mRNA | [67098, 67398] | [66080, 68156] | True | True | True |
| 31/exon | rna-XM_088808078.1 | [28]/mRNA | [67504, 67937] | [66080, 68156] | True | True | True |
| 32/exon | rna-XM_088808078.1 | [28]/mRNA | [68024, 68156] | [66080, 68156] | True | True | True |
| 33/CDS | rna-XM_088808078.1 | [28]/mRNA | [66080, 66300] | [66080, 68156] | True | True | True |
| 34/CDS | rna-XM_088808078.1 | [28]/mRNA | [67098, 67398] | [66080, 68156] | True | True | True |
| 35/CDS | rna-XM_088808078.1 | [28]/mRNA | [67504, 67937] | [66080, 68156] | True | True | True |
| 36/CDS | rna-XM_088808078.1 | [28]/mRNA | [68024, 68156] | [66080, 68156] | True | True | True |

## 候选引用逐项定位

### E01

每个不同 CDS protein_id 与完整 FAA 的首 token 精确接续；逐个 ID 验证，不以行数代替。

- artifacts/models.gff3:10

```text
NC_142639.1	Gnomon	CDS	26289	26546	.	+	0	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
```

- artifacts/models.gff3:11

```text
NC_142639.1	Gnomon	CDS	26633	26714	.	+	0	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
```

- artifacts/models.gff3:12

```text
NC_142639.1	Gnomon	CDS	27131	27204	.	+	2	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
```

- artifacts/models.gff3:13

```text
NC_142639.1	Gnomon	CDS	27292	27352	.	+	0	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
```

- artifacts/models.gff3:14

```text
NC_142639.1	Gnomon	CDS	27443	27585	.	+	2	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
```

- artifacts/models.gff3:22

```text
NC_142639.1	Gnomon	CDS	26289	26546	.	+	0	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
```

- artifacts/models.gff3:23

```text
NC_142639.1	Gnomon	CDS	26633	26714	.	+	0	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
```

- artifacts/models.gff3:24

```text
NC_142639.1	Gnomon	CDS	27131	27204	.	+	2	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
```

- artifacts/models.gff3:25

```text
NC_142639.1	Gnomon	CDS	27292	27352	.	+	0	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
```

- artifacts/models.gff3:26

```text
NC_142639.1	Gnomon	CDS	27432	27469	.	+	2	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
```

- artifacts/models.gff3:33

```text
NC_142639.1	Gnomon	CDS	66080	66300	.	+	0	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
```

- artifacts/models.gff3:34

```text
NC_142639.1	Gnomon	CDS	67098	67398	.	+	1	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
```

- artifacts/models.gff3:35

```text
NC_142639.1	Gnomon	CDS	67504	67937	.	+	0	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
```

- artifacts/models.gff3:36

```text
NC_142639.1	Gnomon	CDS	68024	68156	.	+	1	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
```

- artifacts/proteins.faa:1

```text
>XP_007046407.3 cystathionine beta-synthase (CBS) family protein isoform X1 [Theobroma cacao]
```

- artifacts/proteins.faa:6

```text
>XP_017973981.2 cystathionine beta-synthase (CBS) family protein isoform X2 [Theobroma cacao]
```

- artifacts/proteins.faa:10

```text
>XP_088664204.1 uncharacterized protein LOC148764400 [Theobroma cacao]
```

### E02

所有 Parent 接续且类型、序列/链与父子闭区间符合题面必要合同。

- artifacts/models.gff3:2

```text
NC_142639.1	Gnomon	gene	25281	27766	.	+	.	ID=gene-CBSX3;Dbxref=GeneID:18610617,NCBIOrtholog:830953;Name=CBSX3;description=Cystathionine beta-synthase (CBS) family protein;gbkey=Gene;gene=CBSX3;gene_biotype=protein_coding
```

- artifacts/models.gff3:3

```text
NC_142639.1	Gnomon	mRNA	25281	27766	.	+	.	ID=rna-XM_007046345.3;Parent=gene-CBSX3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;Name=XM_007046345.3;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;model_evidence=Supporting evidence includes similarity to: 15 ESTs%2C 28 Proteins%2C and 100%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 136 samples with support for all annotated introns;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
```

- artifacts/models.gff3:15

```text
NC_142639.1	Gnomon	mRNA	25290	27708	.	+	.	ID=rna-XM_018118492.2;Parent=gene-CBSX3;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;Name=XM_018118492.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;model_evidence=Supporting evidence includes similarity to: 2 Proteins%2C and 91%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 135 samples with support for all annotated introns;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
```

- artifacts/models.gff3:27

```text
NC_142639.1	Gnomon	gene	66080	68156	.	+	.	ID=gene-LOC148764400;Dbxref=GeneID:148764400;Name=LOC148764400;description=uncharacterized LOC148764400;gbkey=Gene;gene=LOC148764400;gene_biotype=protein_coding
```

- artifacts/models.gff3:28

```text
NC_142639.1	Gnomon	mRNA	66080	68156	.	+	.	ID=rna-XM_088808078.1;Parent=gene-LOC148764400;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;Name=XM_088808078.1;gbkey=mRNA;gene=LOC148764400;model_evidence=Supporting evidence includes similarity to: 4 Proteins;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
```

原候选是代表性定位；完成全记录核对还需要以下行。此处补充材料，不修改 expected.json：

artifacts/models.gff3:4, artifacts/models.gff3:5, artifacts/models.gff3:6, artifacts/models.gff3:7, artifacts/models.gff3:8, artifacts/models.gff3:9, artifacts/models.gff3:10, artifacts/models.gff3:11, artifacts/models.gff3:12, artifacts/models.gff3:13, artifacts/models.gff3:14, artifacts/models.gff3:16, artifacts/models.gff3:17, artifacts/models.gff3:18, artifacts/models.gff3:19, artifacts/models.gff3:20, artifacts/models.gff3:21, artifacts/models.gff3:22, artifacts/models.gff3:23, artifacts/models.gff3:24, artifacts/models.gff3:25, artifacts/models.gff3:26, artifacts/models.gff3:29, artifacts/models.gff3:30, artifacts/models.gff3:31, artifacts/models.gff3:32, artifacts/models.gff3:33, artifacts/models.gff3:34, artifacts/models.gff3:35, artifacts/models.gff3:36

## 完整公开题目与候选答案

以下逐文件原文供复核。代码框行号与文件自身的行号不同，请以原始附件或上面的 pointer 为准。

### task.md

````text
# 下游输入审核

请审核Theobroma cacao的一组结构注释记录是否可以交给下游文件连接程序。输出统一规定的JSON。

本题审核输入文件，不是已完成的分析交付；没有提供可回退的旧版本。审核范围仅为给出的两套完整编码gene特征块及对应蛋白，不能外推全基因组注释质量。models.gff3是本次输入，proteins.faa是按ID查找序列的输入；record_counts.json仅列字面计数。

消费者读取GFF的Parent建立gene→mRNA→exon/CDS关系，并按每行CDS的protein_id精确查找FAA header第一个token。每个Parent必须在本题完整记录中存在且类型符合上述层级；子记录必须与父记录同seqid、同链，闭区间完全位于父记录内。FAA记录与不同protein_id对应的一组CDS一一相接。没有声明去版本号、改大小写、以Name或CDS ID代替protein_id等映射。

同一CDS的多片段可以重复ID，不能把CDS行数当蛋白条数。允许异构体和partial=true，不检查模型全长、翻译正确性或生物学功能；这些属性不豁免上述文件连接要求。除必要输入合同外，本题没有其它继续条件，也没有提供运行日志来解释上游过程。

请根据公开记录检查必要合同，并建议最小修复或补证。满足所有必要输入要求时可继续；必要连接或层级要求不能满足时，应先停止下游启动并修复。不要仅凭字面计数接近就认为可以继续。
````

### artifacts/models.gff3

````text
##gff-version 3
NC_142639.1	Gnomon	gene	25281	27766	.	+	.	ID=gene-CBSX3;Dbxref=GeneID:18610617,NCBIOrtholog:830953;Name=CBSX3;description=Cystathionine beta-synthase (CBS) family protein;gbkey=Gene;gene=CBSX3;gene_biotype=protein_coding
NC_142639.1	Gnomon	mRNA	25281	27766	.	+	.	ID=rna-XM_007046345.3;Parent=gene-CBSX3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;Name=XM_007046345.3;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;model_evidence=Supporting evidence includes similarity to: 15 ESTs%2C 28 Proteins%2C and 100%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 136 samples with support for all annotated introns;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	25281	25430	.	+	.	ID=exon-XM_007046345.3-1;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	26284	26546	.	+	.	ID=exon-XM_007046345.3-2;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	26633	26714	.	+	.	ID=exon-XM_007046345.3-3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	27131	27204	.	+	.	ID=exon-XM_007046345.3-4;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	27292	27352	.	+	.	ID=exon-XM_007046345.3-5;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	27443	27766	.	+	.	ID=exon-XM_007046345.3-6;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	CDS	26289	26546	.	+	0	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
NC_142639.1	Gnomon	CDS	26633	26714	.	+	0	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
NC_142639.1	Gnomon	CDS	27131	27204	.	+	2	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
NC_142639.1	Gnomon	CDS	27292	27352	.	+	0	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
NC_142639.1	Gnomon	CDS	27443	27585	.	+	2	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
NC_142639.1	Gnomon	mRNA	25290	27708	.	+	.	ID=rna-XM_018118492.2;Parent=gene-CBSX3;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;Name=XM_018118492.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;model_evidence=Supporting evidence includes similarity to: 2 Proteins%2C and 91%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 135 samples with support for all annotated introns;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	25290	25430	.	+	.	ID=exon-XM_018118492.2-1;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	26284	26546	.	+	.	ID=exon-XM_018118492.2-2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	26633	26714	.	+	.	ID=exon-XM_018118492.2-3;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	27131	27204	.	+	.	ID=exon-XM_018118492.2-4;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	27292	27352	.	+	.	ID=exon-XM_018118492.2-5;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	27432	27708	.	+	.	ID=exon-XM_018118492.2-6;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	CDS	26289	26546	.	+	0	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
NC_142639.1	Gnomon	CDS	26633	26714	.	+	0	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
NC_142639.1	Gnomon	CDS	27131	27204	.	+	2	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
NC_142639.1	Gnomon	CDS	27292	27352	.	+	0	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
NC_142639.1	Gnomon	CDS	27432	27469	.	+	2	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
NC_142639.1	Gnomon	gene	66080	68156	.	+	.	ID=gene-LOC148764400;Dbxref=GeneID:148764400;Name=LOC148764400;description=uncharacterized LOC148764400;gbkey=Gene;gene=LOC148764400;gene_biotype=protein_coding
NC_142639.1	Gnomon	mRNA	66080	68156	.	+	.	ID=rna-XM_088808078.1;Parent=gene-LOC148764400;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;Name=XM_088808078.1;gbkey=mRNA;gene=LOC148764400;model_evidence=Supporting evidence includes similarity to: 4 Proteins;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
NC_142639.1	Gnomon	exon	66080	66300	.	+	.	ID=exon-XM_088808078.1-1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;gbkey=mRNA;gene=LOC148764400;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
NC_142639.1	Gnomon	exon	67098	67398	.	+	.	ID=exon-XM_088808078.1-2;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;gbkey=mRNA;gene=LOC148764400;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
NC_142639.1	Gnomon	exon	67504	67937	.	+	.	ID=exon-XM_088808078.1-3;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;gbkey=mRNA;gene=LOC148764400;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
NC_142639.1	Gnomon	exon	68024	68156	.	+	.	ID=exon-XM_088808078.1-4;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;gbkey=mRNA;gene=LOC148764400;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
NC_142639.1	Gnomon	CDS	66080	66300	.	+	0	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
NC_142639.1	Gnomon	CDS	67098	67398	.	+	1	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
NC_142639.1	Gnomon	CDS	67504	67937	.	+	0	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
NC_142639.1	Gnomon	CDS	68024	68156	.	+	1	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
````

### artifacts/proteins.faa

````text
>XP_007046407.3 cystathionine beta-synthase (CBS) family protein isoform X1 [Theobroma cacao]
MKGAVQAFLLHGNTVKNAVLQRIRVVNPVKRPIIFSRFESVSSARMEEHGFESTTIADIL
KAKGKGADGSWLWCTTDDTVYNAVKSMTQHNVGALVVVKPGEQESIAGIITERDYLRKII
VQGRSSKSAKVGDIMTEENKLITVTPETKVLRAMQLMTDNRIRHIPVIDEKGMVGMVSIG
DVVRAVVIEHREELDRLNAYIQGGY
>XP_017973981.2 cystathionine beta-synthase (CBS) family protein isoform X2 [Theobroma cacao]
MKGAVQAFLLHGNTVKNAVLQRIRVVNPVKRPIIFSRFESVSSARMEEHGFESTTIADIL
KAKGKGADGSWLWCTTDDTVYNAVKSMTQHNVGALVVVKPGEQESIAGIITERDYLRKII
VQGRSSKSAKVGDIMTEENKLITVTPETKVLRAMQLMTVFWQITESDTFQ
>XP_088664204.1 uncharacterized protein LOC148764400 [Theobroma cacao]
MVVSDDDASDKIEDDVEEDDTADWNDKLRDDCEDDYAGRHEDRSKDDRVEQTDIPDCNHA
DSSRGHTTTVVLKSAVIWPVVAIDATHLKSRFKGILFVAVCKYVNEQIYPLAFGIGHVED
EKSWSWFLNQLRCAIGCPENVMFISDQHFSVKNAIQKVYKDAHHDLCNYHLGKKLCKPAY
DSLMRLSTEIWARAWSPVRQYKLMTSNIAECINSCLRHVRKMPIMMLIECIRGMFQRWFH
DQHNEALNLTTPLSSWATDLLNRQFNEACHFFIQAINQVEFQVIGGTKDKVVNLSTKKCS
CGEFQTDLLPCTHAMAAISKCKRAAIEFYSDYYKILSWVEAYAIPIRPVGHPSEWDIPHD
TK
````

### artifacts/record_counts.json

````text
{"cds_rows":14,"exon_rows":16,"gene_rows":2,"mrna_rows":3,"protein_records":3,"protein_residues":737,"unique_cds_ids":3}
````

### expected.json

````text
{"acceptable_decisions":[{"observed_defect":"none","root_cause":"none","verdict":"pass"}],"case_id":"qc_002","independent_review_status":"pending","key_evidence":[{"acceptable_pointers":["artifacts/models.gff3:10","artifacts/models.gff3:11","artifacts/models.gff3:12","artifacts/models.gff3:13","artifacts/models.gff3:14","artifacts/models.gff3:22","artifacts/models.gff3:23","artifacts/models.gff3:24","artifacts/models.gff3:25","artifacts/models.gff3:26","artifacts/models.gff3:33","artifacts/models.gff3:34","artifacts/models.gff3:35","artifacts/models.gff3:36","artifacts/proteins.faa:1","artifacts/proteins.faa:6","artifacts/proteins.faa:10"],"claim_id":"E01","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"每个不同 CDS protein_id 与完整 FAA 的首 token 精确接续；逐个 ID 验证，不以行数代替。","verification_method":"record_connection"},{"acceptable_pointers":["artifacts/models.gff3:2","artifacts/models.gff3:3","artifacts/models.gff3:15","artifacts/models.gff3:27","artifacts/models.gff3:28"],"claim_id":"E02","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"所有 Parent 接续且类型、序列/链与父子闭区间符合题面必要合同。","verification_method":"record_connection"}],"pair_id":"NSP6","rationale":"仅审核本题声明的文件连接与层级；不推断上游运行原因或生物学质量。","root_identifiability":"no_defect","schema_version":"newsource-case-1","user_approved":false}
````

### meta.json

````text
{"case_id":"qc_002","excerpt_policy":"固定规则选两个原始完整编码gene块和所有关联完整蛋白；仅格式重排LF/FAA60列，不代表完整基因组；确定性变体逐字段记录。","historical_rule_report_seen":true,"injection_script":"bench/newsource_validation/cases.py","mechanism_exposure":"seen_in_project_development","mechanism_family":"child_parent_interval","pair_id":"NSP6","pressure_parent":null,"review_status":"draft","schema_version":"newsource-case-1","seed":20261011,"source_exposure":"new_to_model_prompt_tool_development","source_files":[{"path":"sources/GCF_053813885.1_ASM5381388v1_genomic.gff.gz","selection":"{\"gene_ids\": [\"gene-CBSX3\", \"gene-LOC148764400\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": \"unmodified source subset\"}","sha256":"5cf99c51e65515e41d9ff8b0ca4ea70523cbf8dc57bdb31f7c66c43e7cabcadf","source_group":"GCF_053813885.1","source_origin":"/home/Lianjunyang/临时/GCF_053813885.1_ASM5381388v1_genomic.gff.gz"},{"path":"sources/GCF_053813885.1_ASM5381388v1_protein.faa.gz","selection":"{\"gene_ids\": [\"gene-CBSX3\", \"gene-LOC148764400\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": \"unmodified source subset\"}","sha256":"03e85bdc32602c3ab421af4db7bad0a5c29e3999f0791a57507cf5633437cd00","source_group":"GCF_053813885.1","source_origin":"/home/Lianjunyang/临时/GCF_053813885.1_ASM5381388v1_protein.faa.gz"}],"source_group":"GCF_053813885.1","split":"sealed_test","stage":"structural_annotation","synthetic":true,"type":"normal","verbatim_tool_exceptions":[],"visible_contract":{"allowed_id_mapping":"exact only","artifact_roles":{"delivery":["artifacts/models.gff3","artifacts/proteins.faa","artifacts/record_counts.json"],"reference":[]},"consumer_contract":"完整Parent层级、同序列/链、闭区间包含、protein_id精确连接FAA首token","review_target":"input","scope":"declared_subset","usable_previous_result":false}}
````


# qc_009 逐记录材料复核

私有审核补充；不是盲审、真人专家审核或模型成绩。候选答案未改、未冻结。

## 每条 CDS → FAA 精确连接

| GFF 行 | protein_id | FAA header 行 | 精确连接 |
|---|---|---|---|
| 10 | XP_007046407.3 | 1 | True |
| 11 | XP_007046407.3 | 1 | True |
| 12 | XP_007046407.3 | 1 | True |
| 13 | XP_007046407.3 | 1 | True |
| 14 | XP_007046407.3 | 1 | True |
| 22 | XP_017973981.2 | 6 | True |
| 23 | XP_017973981.2 | 6 | True |
| 24 | XP_017973981.2 | 6 | True |
| 25 | XP_017973981.2 | 6 | True |
| 26 | XP_017973981.2 | 6 | True |
| 33 | XP_088664204.1 | 10 | True |
| 34 | XP_088664204.1 | 10 | True |
| 35 | XP_088664204.1 | 10 | True |
| 36 | XP_088664204.1 | 10 | True |

## 全部直接 Parent 关系

| 子行/类型 | Parent | 父行/类型 | 子区间 | 父区间 | 序列相同 | 链相同 | 合同成立 |
|---|---|---|---|---|---|---|---|
| 3/mRNA | gene-CBSX3 | [2]/gene | [25281, 27766] | [25281, 27766] | True | True | True |
| 4/exon | rna-XM_007046345.3 | [3]/mRNA | [25281, 25430] | [25281, 27766] | True | True | True |
| 5/exon | rna-XM_007046345.3 | [3]/mRNA | [26284, 26546] | [25281, 27766] | True | True | True |
| 6/exon | rna-XM_007046345.3 | [3]/mRNA | [26633, 26714] | [25281, 27766] | True | True | True |
| 7/exon | rna-XM_007046345.3 | [3]/mRNA | [27131, 27204] | [25281, 27766] | True | True | True |
| 8/exon | rna-XM_007046345.3 | [3]/mRNA | [27292, 27352] | [25281, 27766] | True | True | True |
| 9/exon | rna-XM_007046345.3 | [3]/mRNA | [27443, 27766] | [25281, 27766] | True | True | True |
| 10/CDS | rna-XM_007046345.3 | [3]/mRNA | [27767, 28024] | [25281, 27766] | True | True | False |
| 11/CDS | rna-XM_007046345.3 | [3]/mRNA | [26633, 26714] | [25281, 27766] | True | True | True |
| 12/CDS | rna-XM_007046345.3 | [3]/mRNA | [27131, 27204] | [25281, 27766] | True | True | True |
| 13/CDS | rna-XM_007046345.3 | [3]/mRNA | [27292, 27352] | [25281, 27766] | True | True | True |
| 14/CDS | rna-XM_007046345.3 | [3]/mRNA | [27443, 27585] | [25281, 27766] | True | True | True |
| 15/mRNA | gene-CBSX3 | [2]/gene | [25290, 27708] | [25281, 27766] | True | True | True |
| 16/exon | rna-XM_018118492.2 | [15]/mRNA | [25290, 25430] | [25290, 27708] | True | True | True |
| 17/exon | rna-XM_018118492.2 | [15]/mRNA | [26284, 26546] | [25290, 27708] | True | True | True |
| 18/exon | rna-XM_018118492.2 | [15]/mRNA | [26633, 26714] | [25290, 27708] | True | True | True |
| 19/exon | rna-XM_018118492.2 | [15]/mRNA | [27131, 27204] | [25290, 27708] | True | True | True |
| 20/exon | rna-XM_018118492.2 | [15]/mRNA | [27292, 27352] | [25290, 27708] | True | True | True |
| 21/exon | rna-XM_018118492.2 | [15]/mRNA | [27432, 27708] | [25290, 27708] | True | True | True |
| 22/CDS | rna-XM_018118492.2 | [15]/mRNA | [26289, 26546] | [25290, 27708] | True | True | True |
| 23/CDS | rna-XM_018118492.2 | [15]/mRNA | [26633, 26714] | [25290, 27708] | True | True | True |
| 24/CDS | rna-XM_018118492.2 | [15]/mRNA | [27131, 27204] | [25290, 27708] | True | True | True |
| 25/CDS | rna-XM_018118492.2 | [15]/mRNA | [27292, 27352] | [25290, 27708] | True | True | True |
| 26/CDS | rna-XM_018118492.2 | [15]/mRNA | [27432, 27469] | [25290, 27708] | True | True | True |
| 28/mRNA | gene-LOC148764400 | [27]/gene | [66080, 68156] | [66080, 68156] | True | True | True |
| 29/exon | rna-XM_088808078.1 | [28]/mRNA | [66080, 66300] | [66080, 68156] | True | True | True |
| 30/exon | rna-XM_088808078.1 | [28]/mRNA | [67098, 67398] | [66080, 68156] | True | True | True |
| 31/exon | rna-XM_088808078.1 | [28]/mRNA | [67504, 67937] | [66080, 68156] | True | True | True |
| 32/exon | rna-XM_088808078.1 | [28]/mRNA | [68024, 68156] | [66080, 68156] | True | True | True |
| 33/CDS | rna-XM_088808078.1 | [28]/mRNA | [66080, 66300] | [66080, 68156] | True | True | True |
| 34/CDS | rna-XM_088808078.1 | [28]/mRNA | [67098, 67398] | [66080, 68156] | True | True | True |
| 35/CDS | rna-XM_088808078.1 | [28]/mRNA | [67504, 67937] | [66080, 68156] | True | True | True |
| 36/CDS | rna-XM_088808078.1 | [28]/mRNA | [68024, 68156] | [66080, 68156] | True | True | True |

## 候选引用逐项定位

### E01

CDS 闭区间越过其 mRNA 父区间；长度不变也不能满足包含要求。

- artifacts/models.gff3:10

```text
NC_142639.1	Gnomon	CDS	27767	28024	.	+	0	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
```

- artifacts/models.gff3:3

```text
NC_142639.1	Gnomon	mRNA	25281	27766	.	+	.	ID=rna-XM_007046345.3;Parent=gene-CBSX3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;Name=XM_007046345.3;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;model_evidence=Supporting evidence includes similarity to: 15 ESTs%2C 28 Proteins%2C and 100%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 136 samples with support for all annotated introns;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
```

## 完整公开题目与候选答案

以下逐文件原文供复核。代码框行号与文件自身的行号不同，请以原始附件或上面的 pointer 为准。

### task.md

````text
# 下游输入审核

请审核Theobroma cacao的一组结构注释记录是否可以交给下游文件连接程序。输出统一规定的JSON。

本题审核输入文件，不是已完成的分析交付；没有提供可回退的旧版本。审核范围仅为给出的两套完整编码gene特征块及对应蛋白，不能外推全基因组注释质量。models.gff3是本次输入，proteins.faa是按ID查找序列的输入；record_counts.json仅列字面计数。

消费者读取GFF的Parent建立gene→mRNA→exon/CDS关系，并按每行CDS的protein_id精确查找FAA header第一个token。每个Parent必须在本题完整记录中存在且类型符合上述层级；子记录必须与父记录同seqid、同链，闭区间完全位于父记录内。FAA记录与不同protein_id对应的一组CDS一一相接。没有声明去版本号、改大小写、以Name或CDS ID代替protein_id等映射。

同一CDS的多片段可以重复ID，不能把CDS行数当蛋白条数。允许异构体和partial=true，不检查模型全长、翻译正确性或生物学功能；这些属性不豁免上述文件连接要求。除必要输入合同外，本题没有其它继续条件，也没有提供运行日志来解释上游过程。

请根据公开记录检查必要合同，并建议最小修复或补证。满足所有必要输入要求时可继续；必要连接或层级要求不能满足时，应先停止下游启动并修复。不要仅凭字面计数接近就认为可以继续。
````

### artifacts/models.gff3

````text
##gff-version 3
NC_142639.1	Gnomon	gene	25281	27766	.	+	.	ID=gene-CBSX3;Dbxref=GeneID:18610617,NCBIOrtholog:830953;Name=CBSX3;description=Cystathionine beta-synthase (CBS) family protein;gbkey=Gene;gene=CBSX3;gene_biotype=protein_coding
NC_142639.1	Gnomon	mRNA	25281	27766	.	+	.	ID=rna-XM_007046345.3;Parent=gene-CBSX3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;Name=XM_007046345.3;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;model_evidence=Supporting evidence includes similarity to: 15 ESTs%2C 28 Proteins%2C and 100%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 136 samples with support for all annotated introns;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	25281	25430	.	+	.	ID=exon-XM_007046345.3-1;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	26284	26546	.	+	.	ID=exon-XM_007046345.3-2;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	26633	26714	.	+	.	ID=exon-XM_007046345.3-3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	27131	27204	.	+	.	ID=exon-XM_007046345.3-4;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	27292	27352	.	+	.	ID=exon-XM_007046345.3-5;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	exon	27443	27766	.	+	.	ID=exon-XM_007046345.3-6;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XM_007046345.3,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X1;transcript_id=XM_007046345.3
NC_142639.1	Gnomon	CDS	27767	28024	.	+	0	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
NC_142639.1	Gnomon	CDS	26633	26714	.	+	0	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
NC_142639.1	Gnomon	CDS	27131	27204	.	+	2	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
NC_142639.1	Gnomon	CDS	27292	27352	.	+	0	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
NC_142639.1	Gnomon	CDS	27443	27585	.	+	2	ID=cds-XP_007046407.3;Parent=rna-XM_007046345.3;Dbxref=GeneID:18610617,GenBank:XP_007046407.3,NCBIOrtholog:830953;Name=XP_007046407.3;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X1;protein_id=XP_007046407.3
NC_142639.1	Gnomon	mRNA	25290	27708	.	+	.	ID=rna-XM_018118492.2;Parent=gene-CBSX3;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;Name=XM_018118492.2;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;model_evidence=Supporting evidence includes similarity to: 2 Proteins%2C and 91%25 coverage of the annotated genomic feature by RNAseq alignments%2C including 135 samples with support for all annotated introns;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	25290	25430	.	+	.	ID=exon-XM_018118492.2-1;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	26284	26546	.	+	.	ID=exon-XM_018118492.2-2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	26633	26714	.	+	.	ID=exon-XM_018118492.2-3;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	27131	27204	.	+	.	ID=exon-XM_018118492.2-4;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	27292	27352	.	+	.	ID=exon-XM_018118492.2-5;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	exon	27432	27708	.	+	.	ID=exon-XM_018118492.2-6;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XM_018118492.2,NCBIOrtholog:830953;experiment=COORDINATES: polyA evidence [ECO:0006239];gbkey=mRNA;gene=CBSX3;product=Cystathionine beta-synthase (CBS) family protein%2C transcript variant X2;transcript_id=XM_018118492.2
NC_142639.1	Gnomon	CDS	26289	26546	.	+	0	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
NC_142639.1	Gnomon	CDS	26633	26714	.	+	0	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
NC_142639.1	Gnomon	CDS	27131	27204	.	+	2	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
NC_142639.1	Gnomon	CDS	27292	27352	.	+	0	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
NC_142639.1	Gnomon	CDS	27432	27469	.	+	2	ID=cds-XP_017973981.2;Parent=rna-XM_018118492.2;Dbxref=GeneID:18610617,GenBank:XP_017973981.2,NCBIOrtholog:830953;Name=XP_017973981.2;gbkey=CDS;gene=CBSX3;product=cystathionine beta-synthase (CBS) family protein isoform X2;protein_id=XP_017973981.2
NC_142639.1	Gnomon	gene	66080	68156	.	+	.	ID=gene-LOC148764400;Dbxref=GeneID:148764400;Name=LOC148764400;description=uncharacterized LOC148764400;gbkey=Gene;gene=LOC148764400;gene_biotype=protein_coding
NC_142639.1	Gnomon	mRNA	66080	68156	.	+	.	ID=rna-XM_088808078.1;Parent=gene-LOC148764400;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;Name=XM_088808078.1;gbkey=mRNA;gene=LOC148764400;model_evidence=Supporting evidence includes similarity to: 4 Proteins;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
NC_142639.1	Gnomon	exon	66080	66300	.	+	.	ID=exon-XM_088808078.1-1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;gbkey=mRNA;gene=LOC148764400;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
NC_142639.1	Gnomon	exon	67098	67398	.	+	.	ID=exon-XM_088808078.1-2;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;gbkey=mRNA;gene=LOC148764400;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
NC_142639.1	Gnomon	exon	67504	67937	.	+	.	ID=exon-XM_088808078.1-3;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;gbkey=mRNA;gene=LOC148764400;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
NC_142639.1	Gnomon	exon	68024	68156	.	+	.	ID=exon-XM_088808078.1-4;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XM_088808078.1;gbkey=mRNA;gene=LOC148764400;product=uncharacterized LOC148764400;transcript_id=XM_088808078.1
NC_142639.1	Gnomon	CDS	66080	66300	.	+	0	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
NC_142639.1	Gnomon	CDS	67098	67398	.	+	1	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
NC_142639.1	Gnomon	CDS	67504	67937	.	+	0	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
NC_142639.1	Gnomon	CDS	68024	68156	.	+	1	ID=cds-XP_088664204.1;Parent=rna-XM_088808078.1;Dbxref=GeneID:148764400,GenBank:XP_088664204.1;Name=XP_088664204.1;gbkey=CDS;gene=LOC148764400;product=uncharacterized protein LOC148764400;protein_id=XP_088664204.1
````

### artifacts/proteins.faa

````text
>XP_007046407.3 cystathionine beta-synthase (CBS) family protein isoform X1 [Theobroma cacao]
MKGAVQAFLLHGNTVKNAVLQRIRVVNPVKRPIIFSRFESVSSARMEEHGFESTTIADIL
KAKGKGADGSWLWCTTDDTVYNAVKSMTQHNVGALVVVKPGEQESIAGIITERDYLRKII
VQGRSSKSAKVGDIMTEENKLITVTPETKVLRAMQLMTDNRIRHIPVIDEKGMVGMVSIG
DVVRAVVIEHREELDRLNAYIQGGY
>XP_017973981.2 cystathionine beta-synthase (CBS) family protein isoform X2 [Theobroma cacao]
MKGAVQAFLLHGNTVKNAVLQRIRVVNPVKRPIIFSRFESVSSARMEEHGFESTTIADIL
KAKGKGADGSWLWCTTDDTVYNAVKSMTQHNVGALVVVKPGEQESIAGIITERDYLRKII
VQGRSSKSAKVGDIMTEENKLITVTPETKVLRAMQLMTVFWQITESDTFQ
>XP_088664204.1 uncharacterized protein LOC148764400 [Theobroma cacao]
MVVSDDDASDKIEDDVEEDDTADWNDKLRDDCEDDYAGRHEDRSKDDRVEQTDIPDCNHA
DSSRGHTTTVVLKSAVIWPVVAIDATHLKSRFKGILFVAVCKYVNEQIYPLAFGIGHVED
EKSWSWFLNQLRCAIGCPENVMFISDQHFSVKNAIQKVYKDAHHDLCNYHLGKKLCKPAY
DSLMRLSTEIWARAWSPVRQYKLMTSNIAECINSCLRHVRKMPIMMLIECIRGMFQRWFH
DQHNEALNLTTPLSSWATDLLNRQFNEACHFFIQAINQVEFQVIGGTKDKVVNLSTKKCS
CGEFQTDLLPCTHAMAAISKCKRAAIEFYSDYYKILSWVEAYAIPIRPVGHPSEWDIPHD
TK
````

### artifacts/record_counts.json

````text
{"cds_rows":14,"exon_rows":16,"gene_rows":2,"mrna_rows":3,"protein_records":3,"protein_residues":737,"unique_cds_ids":3}
````

### expected.json

````text
{"acceptable_decisions":[{"observed_defect":"gff_hierarchy_inconsistent","root_cause":"gff_hierarchy_error","verdict":"block"}],"case_id":"qc_009","independent_review_status":"pending","key_evidence":[{"acceptable_pointers":["artifacts/models.gff3:10","artifacts/models.gff3:3"],"claim_id":"E01","required_for_joint":true,"review_note":"Author AI draft; not independent human review; pending user approval.","statement":"CDS 闭区间越过其 mRNA 父区间；长度不变也不能满足包含要求。","verification_method":"record_connection"}],"pair_id":"NSP6","rationale":"仅审核本题声明的文件连接与层级；不推断上游运行原因或生物学质量。","root_identifiability":"confirmed","schema_version":"newsource-case-1","user_approved":false}
````

### meta.json

````text
{"case_id":"qc_009","excerpt_policy":"固定规则选两个原始完整编码gene块和所有关联完整蛋白；仅格式重排LF/FAA60列，不代表完整基因组；确定性变体逐字段记录。","historical_rule_report_seen":true,"injection_script":"bench/newsource_validation/cases.py","mechanism_exposure":"seen_in_project_development","mechanism_family":"child_parent_interval","pair_id":"NSP6","pressure_parent":null,"review_status":"draft","schema_version":"newsource-case-1","seed":20261011,"source_exposure":"new_to_model_prompt_tool_development","source_files":[{"path":"sources/GCF_053813885.1_ASM5381388v1_genomic.gff.gz","selection":"{\"gene_ids\": [\"gene-CBSX3\", \"gene-LOC148764400\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": {\"after\": [\"27767\", \"28024\"], \"attribute\": \"CDS coordinates\", \"before\": [\"26289\", \"26546\"], \"policy\": \"one segment moved just beyond its own mRNA end, same segment length\"}}","sha256":"5cf99c51e65515e41d9ff8b0ca4ea70523cbf8dc57bdb31f7c66c43e7cabcadf","source_group":"GCF_053813885.1","source_origin":"/home/Lianjunyang/临时/GCF_053813885.1_ASM5381388v1_genomic.gff.gz"},{"path":"sources/GCF_053813885.1_ASM5381388v1_protein.faa.gz","selection":"{\"gene_ids\": [\"gene-CBSX3\", \"gene-LOC148764400\"], \"policy\": {\"answer_status\": \"draft\", \"api_calls\": 0, \"artifact_read_pages_maximum\": 4, \"candidate_limit\": 50, \"candidate_limit_definition\": \"first 50 eligible blocks, not first 50 raw genes\", \"case_order\": \"sort SHA256(seed|accession|variant) then assign qc_NNN\", \"genes_selected\": 2, \"max_feature_rows_per_gene\": 40, \"max_visible_bytes\": 30000, \"normal_scope\": \"only declared closed connected coding subset\", \"page_bytes\": 16000, \"page_lines\": 200, \"require_multisegment_cds\": true, \"same_source_pairs\": true, \"seed\": 20261011, \"selection_order\": \"source GFF order; first two individually closed, connected eligible coding blocks within byte limit\"}, \"transform\": {\"after\": [\"27767\", \"28024\"], \"attribute\": \"CDS coordinates\", \"before\": [\"26289\", \"26546\"], \"policy\": \"one segment moved just beyond its own mRNA end, same segment length\"}}","sha256":"03e85bdc32602c3ab421af4db7bad0a5c29e3999f0791a57507cf5633437cd00","source_group":"GCF_053813885.1","source_origin":"/home/Lianjunyang/临时/GCF_053813885.1_ASM5381388v1_protein.faa.gz"}],"source_group":"GCF_053813885.1","split":"sealed_test","stage":"structural_annotation","synthetic":true,"type":"fault","verbatim_tool_exceptions":[],"visible_contract":{"allowed_id_mapping":"exact only","artifact_roles":{"delivery":["artifacts/models.gff3","artifacts/proteins.faa","artifacts/record_counts.json"],"reference":[]},"consumer_contract":"完整Parent层级、同序列/链、闭区间包含、protein_id精确连接FAA首token","review_target":"input","scope":"declared_subset","usable_previous_result":false}}
````
